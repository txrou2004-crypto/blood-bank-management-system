-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: bloodbankmanagementdb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bloodstock`
--

DROP TABLE IF EXISTS `bloodstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bloodstock` (
  `StockID` char(6) NOT NULL,
  `BloodType` enum('A','B','AB','O') NOT NULL,
  `Quantity` int NOT NULL DEFAULT '0',
  `DateReceived` date NOT NULL DEFAULT (curdate()),
  `ExpiryDate` date NOT NULL,
  `Status` enum('Available','Used','Expired') NOT NULL DEFAULT 'Available',
  `DonationID` char(6) NOT NULL,
  PRIMARY KEY (`StockID`),
  KEY `DonationID` (`DonationID`),
  CONSTRAINT `bloodstock_ibfk_1` FOREIGN KEY (`DonationID`) REFERENCES `donation` (`DonationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bloodstock`
--

LOCK TABLES `bloodstock` WRITE;
/*!40000 ALTER TABLE `bloodstock` DISABLE KEYS */;
INSERT INTO `bloodstock` VALUES ('BS001','A',450,'2025-01-15','2025-02-26','Available','DN001'),('BS002','A',500,'2025-03-20','2025-05-01','Available','DN002'),('BS003','B',470,'2025-02-10','2025-03-24','Available','DN003'),('BS004','AB',450,'2025-04-05','2025-05-17','Available','DN004'),('BS005','O',500,'2025-01-25','2025-03-07','Available','DN005'),('BS006','A',450,'2025-03-10','2025-04-21','Available','DN006'),('BS007','B',480,'2025-02-28','2025-04-11','Available','DN007'),('BS008','AB',500,'2025-03-15','2025-04-26','Available','DN008'),('BS009','O',470,'2025-01-30','2025-03-11','Available','DN009'),('BS010','A',450,'2025-04-12','2025-05-24','Available','DN010'),('BS011','O',500,'2025-11-30','2026-04-27','Available','DN011'),('BS012','O',450,'2026-01-08','2026-02-08','Available','DN012'),('BS013','O',460,'2026-01-08','2026-02-08','Available','DN013'),('BS014','O',470,'2026-01-08','2026-02-08','Available','DN014'),('BS015','O',220,'2026-01-08','2026-01-08','Available','DN015');
/*!40000 ALTER TABLE `bloodstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donation`
--

DROP TABLE IF EXISTS `donation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `donation` (
  `DonationID` char(6) NOT NULL,
  `DonationDate` date NOT NULL DEFAULT (curdate()),
  `BloodVolume` decimal(5,2) NOT NULL,
  `BloodType` enum('A','B','AB','O') NOT NULL,
  `DonorID` char(6) NOT NULL,
  `StaffID` char(6) NOT NULL,
  PRIMARY KEY (`DonationID`),
  KEY `DonorID` (`DonorID`),
  KEY `StaffID` (`StaffID`),
  CONSTRAINT `donation_ibfk_1` FOREIGN KEY (`DonorID`) REFERENCES `donor` (`DonorID`),
  CONSTRAINT `donation_ibfk_2` FOREIGN KEY (`StaffID`) REFERENCES `staff` (`StaffID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donation`
--

LOCK TABLES `donation` WRITE;
/*!40000 ALTER TABLE `donation` DISABLE KEYS */;
INSERT INTO `donation` VALUES ('DN001','2025-01-15',470.00,'O','D001','S003'),('DN002','2025-03-20',500.00,'A','D002','S001'),('DN003','2025-02-10',470.00,'B','D003','S003'),('DN004','2025-04-05',450.00,'AB','D004','S002'),('DN005','2025-01-25',500.00,'O','D005','S004'),('DN006','2025-03-10',450.00,'A','D006','S001'),('DN007','2025-02-28',480.00,'B','D007','S003'),('DN008','2025-03-15',500.00,'AB','D008','S004'),('DN009','2025-01-30',470.00,'O','D009','S002'),('DN010','2025-04-12',450.00,'A','D010','S001'),('DN011','2025-11-30',500.00,'O','D001','S001'),('DN012','2026-01-08',450.00,'O','D011','S001'),('DN013','2026-01-08',460.00,'O','D012','S004'),('DN014','2026-01-08',470.00,'O','D014','S002'),('DN015','2026-01-08',430.00,'O','D001','S006'),('DN016','2026-01-12',470.00,'A','D016','S001');
/*!40000 ALTER TABLE `donation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donor`
--

DROP TABLE IF EXISTS `donor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `donor` (
  `DonorID` char(6) NOT NULL,
  `DonorName` varchar(100) NOT NULL,
  `DonorGender` enum('Male','Female') NOT NULL,
  `DonorDOB` date NOT NULL,
  `DonorAge` int NOT NULL,
  `DonorAddress` varchar(255) NOT NULL,
  `DonorPhone` varchar(15) NOT NULL,
  `DonorEmail` varchar(100) NOT NULL,
  `DonorBloodType` enum('A','B','AB','O') NOT NULL,
  `DonorHeight` decimal(5,2) NOT NULL,
  `DonorWeight` decimal(5,2) NOT NULL,
  `DonorPassword` varchar(255) NOT NULL,
  `LastDonationDate` date DEFAULT NULL,
  PRIMARY KEY (`DonorID`),
  UNIQUE KEY `DonorPhone` (`DonorPhone`),
  UNIQUE KEY `DonorEmail` (`DonorEmail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donor`
--

LOCK TABLES `donor` WRITE;
/*!40000 ALTER TABLE `donor` DISABLE KEYS */;
INSERT INTO `donor` VALUES ('D001','Mohd Hafiz','Male','1990-03-14',35,'12 Jalan Melur, Kuala Lumpur','0123451111','mohdhafiz@gmail.com','O',172.00,70.00,'pass001','2026-01-08'),('D002','Siti Sarah','Female','1992-07-21',33,'45 Jalan Anggerik, Selangor','0198762222','sitisarah@yahoo.com','A',160.00,54.00,'pass002','2025-03-20'),('D003','Goh Wei Jie','Male','1988-11-30',37,'78 Jalan Bukit Bintang, Kuala Lumpur','0171233333','gohweijie@gmail.com','B',175.00,73.00,'pass003','2025-02-10'),('D004','Lim Mei Fang','Female','1995-02-10',30,'90 Jalan Ipoh, Kuala Lumpur','0162344444','limmeifang@yahoo.com','AB',158.00,50.00,'pass004','2025-04-05'),('D005','Ravi Kumar','Male','1985-07-18',40,'23 Jalan Kuching, Selangor','0123455555','ravikumar@gmail.com','O',174.00,76.00,'pass005','2025-01-25'),('D006','Aina Farhana','Female','1993-09-12',32,'56 Jalan Ampang, Kuala Lumpur','0191236666','ainafarhana@yahoo.com','A',162.00,53.00,'pass006','2025-03-10'),('D007','Chong Li Mei','Female','1991-12-20',34,'12 Jalan Sentul, Kuala Lumpur','0172347777','chonglimei@gmail.com','B',159.00,49.00,'pass007','2025-02-28'),('D008','Arjun Singh','Male','1987-04-15',38,'34 Jalan Gasing, Selangor','0163458888','arjunsingh@yahoo.com','AB',178.00,81.00,'pass008','2025-03-15'),('D009','Lee Jun Hao','Male','1990-06-22',35,'67 Jalan Ampang, Kuala Lumpur','0124569999','leejunhao@gmail.com','O',174.00,71.00,'pass009','2025-01-30'),('D010','Nur Hidayah','Female','1994-01-08',31,'89 Jalan Klang Lama, Selangor','0192340000','nurhidayah@yahoo.com','A',161.00,52.00,'pass010','2025-04-12'),('D011','Albie Yoke','Female','1987-10-27',38,'67 Taman Gembira Melaka','0164456888','albie@gmail.com','O',173.00,67.00,'passd011','2026-01-08'),('D012','John','Male','2005-05-25',20,'18 Taman Tuah, Melaka','0123456777','john1@gmail.com','O',187.00,86.00,'pass101','2026-01-08'),('D013','Jane','Female','2003-12-27',22,'14 Taman Merdeka Melaka','0123459876','jane@gmail.com','AB',157.00,48.00,'jane013','2026-01-08'),('D014','Ahmad Firdaus','Male','1992-03-14',34,'23 Jalan Melur, Selangor','0121113758','ahmadfirdaus@gmail.com','O',172.00,68.00,'ahmad014','2026-01-08'),('D015','Nur Aisyah','Female','1998-08-27',28,'11 Jalan Bukit Indah, Kedah','0178921345','nuraisyah@gmail.com','B',160.00,54.00,'aisyah015',NULL),('D016','Jasmine','Female','2001-01-05',25,'17 Taman Muzaffar, Melaka','0183647075','jasmine@gmail.com','A',165.00,49.00,'jasmine016','2026-01-12');
/*!40000 ALTER TABLE `donor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rewardpoints`
--

DROP TABLE IF EXISTS `rewardpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rewardpoints` (
  `RewardID` char(6) NOT NULL,
  `TotalPoints` int NOT NULL DEFAULT '0',
  `LastUpdated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `RewardLevel` enum('Bronze','Silver','Gold','Platinum') NOT NULL DEFAULT 'Bronze',
  `DonorID` char(6) NOT NULL,
  PRIMARY KEY (`RewardID`),
  UNIQUE KEY `DonorID` (`DonorID`),
  CONSTRAINT `rewardpoints_ibfk_1` FOREIGN KEY (`DonorID`) REFERENCES `donor` (`DonorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rewardpoints`
--

LOCK TABLES `rewardpoints` WRITE;
/*!40000 ALTER TABLE `rewardpoints` DISABLE KEYS */;
INSERT INTO `rewardpoints` VALUES ('R001',70,'2026-01-08 20:33:01','Bronze','D001'),('R002',120,'2025-11-08 15:36:28','Silver','D002'),('R003',200,'2025-11-08 15:36:28','Gold','D003'),('R004',80,'2025-11-08 15:36:28','Bronze','D004'),('R005',250,'2025-11-08 15:36:28','Gold','D005'),('R006',60,'2025-11-08 15:36:28','Bronze','D006'),('R007',150,'2025-11-08 15:36:28','Silver','D007'),('R008',300,'2025-11-08 15:36:28','Platinum','D008'),('R009',90,'2025-11-08 15:36:28','Bronze','D009'),('R010',180,'2025-11-08 15:36:28','Gold','D010'),('R011',20,'2026-01-08 20:06:29','Bronze','D011'),('R012',10,'2026-01-08 16:37:44','Bronze','D013'),('R013',10,'2026-01-08 20:31:40','Bronze','D012'),('R014',10,'2026-01-08 20:32:26','Bronze','D014'),('R015',10,'2026-01-12 15:09:58','Bronze','D016');
/*!40000 ALTER TABLE `rewardpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `StaffID` char(6) NOT NULL,
  `StaffName` varchar(100) NOT NULL,
  `StaffGender` enum('Male','Female') NOT NULL,
  `StaffAge` int NOT NULL,
  `StaffPhone` varchar(15) NOT NULL,
  `StaffEmail` varchar(100) NOT NULL,
  `StaffPosition` varchar(50) NOT NULL,
  `StaffPassword` varchar(255) NOT NULL,
  `StaffRole` enum('Admin','Staff') NOT NULL DEFAULT 'Staff',
  PRIMARY KEY (`StaffID`),
  UNIQUE KEY `StaffEmail` (`StaffEmail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES ('S001','Ahmad Faiz','Male',34,'0123456789','ahmadfaiz@gmail.com','Doctor','pass123','Admin'),('S002','Nurul Aisyah','Female',29,'0198765432','nurulaisyah@yahoo.com','Nurse','nurse123','Admin'),('S003','Lim Wei Ming','Male',31,'0171234567','limweiming@gmail.com','Lab Technician','labpass1','Staff'),('S004','Tan Mei Ling','Female',28,'0162345678','tanmeiling@yahoo.com','Nurse','nurse456','Staff'),('S005','Rajesh Kumar','Male',36,'0123456790','rajeshkumar@gmail.com','Doctor','docpass1','Admin'),('S006','Siti Hajar','Female',32,'0191234567','sitihajar@yahoo.com','Lab Technician','labtech2','Staff'),('S007','Chong Li Hua','Female',30,'0172345678','chonglihua@gmail.com','Nurse','nurse789','Staff'),('S008','Arun Prakash','Male',35,'0163456789','arunprakash@yahoo.com','Doctor','docpass2','Admin'),('S009','Lee Chee Keong','Male',33,'0124567890','leechkeong@gmail.com','Lab Technician','labtech3','Staff'),('S010','Aishah Rahman','Female',27,'0192345678','aishahrahman@yahoo.com','Nurse','nurse321','Staff'),('S011','Chin Weng Leong','Male',57,'0123333777','chin@gmail.com','Doctor','passs011','Staff'),('S012','Susan','Female',43,'0123456788','susan1@gmail.com','Nurse','pass100','Staff'),('S013','Ling Jia Xuan','Female',60,'0162533635','jx@gmail.com','Nurse','jiaxuan013','Staff'),('S014','Nadhirah','Female',34,'01127621016','nad@gmail.com','Doctor','nad014','Admin'),('S015','Law Kok Liang','Male',47,'0183923881','kokliang@gmail.com','Lab Technician','kokliang015','Admin'),('S016','Mun Pin Pin','Male',23,'0185987932','mpp@gmail.com','Doctor','mpp016','Staff');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-21  8:48:30
