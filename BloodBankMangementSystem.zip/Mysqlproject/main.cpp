#include <iostream>
#include <ctime>
#include <iomanip>
#include <conio.h>
#include <limits>
#include <stdexcept>
#include <fstream>
#include <windows.h>
#include <sstream>
#include <mysql_connection.h>
#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/prepared_statement.h>
#include <cppconn/resultset.h>

using namespace std;

const string server = "tcp://127.0.0.1:3306";

const string username = "root";

const string password = "0330";

void testDBConnection() {

    try {

        sql::Driver* driver = get_driver_instance();

        sql::Connection* con = driver->connect(server, username, password);

        con->setSchema("bloodbankmanagementdb");

        cout << "Database connection successful!" << endl;

        delete con; // Clean up

    }

    catch (sql::SQLException& e) {

        cout << "Could not connect to server. Error message: " << e.what() << endl;

        system("pause");

        exit(1);

    }

}

enum Color {
    Black,
    Blue,
    Green,
    Cyan,
    Red,
    Magenta,
    Yellow,
    White,
    Gray,
    Light_Blue,
    Light_Green,
    Light_Aqua,
    Light_Red,
    Light_Purple,
    Light_Yellow,
    Bright_White,
};

string foreground(Color color) {
    switch (color) {
    case Black:
        return "\u001b[30m";
    case Blue:
        return "\u001b[34m";
    case Green:
        return "\u001b[32m";
    case Cyan:
        return "\u001b[36m";
    case Red:
        return "\u001b[31m";
    case Magenta:
        return "\u001b[35m";
    case Yellow:
        return "\u001b[33m";
    case White:
        return "\u001b[37m";
    case Gray:
        return "\u001b[30;1m";
    case Light_Blue:
        return "\u001b[34;1m";
    case Light_Green:
        return "\u001b[32;1m";
    case Light_Aqua:
        return "\u001b[36;1m";
    case Light_Red:
        return "\u001b[31;1m";
    case Light_Purple:
        return "\u001b[35;1m";
    case Light_Yellow:
        return "\u001b[33;1m";
    case Bright_White:
        return "\u001b[37;1m";
    default:
        throw std::invalid_argument("invalid value");
    }
}

string resetANSI() {
    return "\u001b[0m";
}

int qstate;
sql::Connection* conn; 
string StaffID, DonorID, StaffName, DonorName;

int main();
void MainLogin(); 
void MainMenu();
void Registration(); 
void ForgetPassword();

void AdminLogin();
void AdminMainMenu(string);
void AdminControlMain(sql::Connection* conn);

void AdminAdd(sql::Connection* conn);
void AdminDelete(sql::Connection* conn);
void AdminUpdate(sql::Connection* conn);
void AdminSearch(sql::Connection* conn);
void AdminDisplay(sql::Connection* conn, string);
void AdminReportMain(sql::Connection* conn, const string&);

void StaffLogin();
void StaffMainMenu(string, string);
void StaffControlMain();
void StaffAccount(const string&, sql::Connection* conn, const string&, const string&);

void StaffControlAdd();
void AddDonorMenu(sql::Connection* conn);
void AddBloodMenu(sql::Connection* conn);
void AddDonationMenu(sql::Connection* conn);

void StaffControlDelete();
void DeleteDonor(sql::Connection* conn);
void DeleteBlood(sql::Connection* conn);
void DeleteDonation(sql::Connection* conn);

void StaffControlUpdate();
void UpdateDonor(sql::Connection* conn);
void UpdateBlood(sql::Connection* conn);
void UpdateDonation(sql::Connection* conn);

void StaffControlSearch();
void SearchDonor(sql::Connection* conn);
void SearchBlood(sql::Connection* conn);
void SearchDonation(sql::Connection* conn);

void RecentDonation(sql::Connection* conn, string);

void StaffReport(sql::Connection* conn, string, string);

void DonorLogin();
void DonorMainMenu(string, string);
void DonorDonation(string);
void DonorAccount(const string&);
void RewardPoints(const string&);

void ShowTime();
int calculateAge(int, int, int);

//main function
int main() {

    testDBConnection();

    MainMenu();

    system("pause");

    return 0;

}

void MainMenu()
{
    system("cls");
    testDBConnection();
    char optionMain;
    ShowTime();
    cout << foreground(Blue) << "---------------------------------------------" << resetANSI() << endl;
    cout << foreground(Red) << " Welcome to Blood Bank Management System " << resetANSI() << endl;
    cout << foreground(Blue) << "---------------------------------------------" << resetANSI() << endl;
    cout << endl;

    cout << foreground(Light_Aqua) << " [1] Login " << resetANSI() << endl;
    cout << foreground(Yellow) << " [2] Register " << resetANSI() << endl;
    cout << foreground(Red) << " [3] Exit " << resetANSI() << endl;
    cout << endl;

    cout << foreground(Blue) << "Enter your option: " << resetANSI();
    cin >> optionMain;

    while (optionMain != '1' && optionMain != '2' && optionMain != '3' && optionMain != '4')
    {
        cout << "Invalid Choice. Please enter again: " << endl;
        cin >> optionMain;
    }

    if (optionMain == '1') MainLogin();
    else if (optionMain == '2') Registration();
    else if (optionMain == '3') exit(3);
    else {
        cout << "Invalid!";
        system("pause");
        main();
    };
}

//login main menu
void MainLogin()
{
    system("cls");
    char choiceLogin;
    cout << "-----------------" << endl;
    cout << "      LOGIN      " << endl;
    cout << "-----------------" << endl << endl;

    cout << "[1] Login As Admin " << endl;
    cout << "[2] Login As Staff " << endl;
    cout << "[3] Login As Donor " << endl;
    cout << "[4] Forget Password" << endl;
    cout << "[5] Back to Main Menu" << endl;
    cout << endl;

    while (1) {
        cout <<"Enter your choice (Number 1 - 5 only): " ;
        cin >> choiceLogin;

        if (choiceLogin == '1') {
            AdminLogin();
        }
        else if (choiceLogin == '2') {
            StaffLogin();
        }
        else if (choiceLogin == '3') {
            DonorLogin();
        }
        else if (choiceLogin == '4') {
            system("cls");
            ForgetPassword();
        }
        else if (choiceLogin == '5') {
            system("cls");
            main();
        }
        else {
            cout << "Invalid Choice. Please enter again. ";
            cout << "\n";
            system("pause");
            MainLogin();
        }
    }
}

void AdminLogin()
{
    string StaffPassword;
    system("cls");
    cout << "----------------" << endl;
    cout << " LOGIN AS ADMIN " << endl;
    cout << "----------------" << endl;
    cout << endl;

    cout << "Enter ID: ";
    cin >> StaffID;
    cout << "Enter Password: ";

    char ch;
    while ((ch = _getch()) != 13)
    {
        StaffPassword += ch;
        cout << "*";
    }

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT StaffName FROM staff WHERE StaffID = ? AND StaffPassword = ? AND StaffRole = 'Admin'"
        );

        pstmt->setString(1, StaffID);
        pstmt->setString(2, StaffPassword);

        sql::ResultSet* res = pstmt->executeQuery();

        if (res->next()) {
            StaffName = res->getString("StaffName");

            delete res;
            delete pstmt;
            delete conn;

            system("cls");
            AdminMainMenu(StaffName);
        }
        else {
            delete res;
            delete pstmt;
            delete conn;

            char c;
            cout << "\nInvalid username or password. Try again? (Y/N): ";
            cin >> c;
            if (c == 'y' || c == 'Y')
                AdminLogin();
            else
                MainLogin();
        }
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
    }
}

void AdminMainMenu(string name)
{
    char AdminMain;
    system("cls");
    cout << "-----------------" << endl;
    cout << " ADMIN MAIN MENU " << endl;
    cout << "-----------------" << endl;

    cout << "Welcome, admin " << name << "!" << endl;
    cout << endl;

    cout << "[1] Administration Control" << endl;
    cout << "[2] Staff Records" << endl;
    cout << "[3] Report Generation" << endl;
    cout << "[4] Back to main menu" << endl;

    cout << "\nPlease enter your choice: ";
    cin >> AdminMain;

    if (AdminMain == '1')
    {
        AdminControlMain(conn);
    }
    else if (AdminMain == '2')
    {
        AdminDisplay(conn, StaffName);
    }
    else if (AdminMain == '3')
    {
        AdminReportMain(conn, StaffName);
    }
    else if (AdminMain == '4')
    {
        main();
    }
    else {
        cout << "Invalid!" << endl;
        AdminMainMenu(name);
    }
}

void AdminControlMain(sql::Connection* conn)
{
    char adminControl;
    system("CLS");
    cout << "--------------------" << endl;
    cout << " ADMIN CONTROL MENU " << endl;
    cout << "--------------------" << endl;

    cout << "Welcome, admin! What would you like to do with Staff?" << endl;
    cout << endl;

    cout << "[1] Add Staff Record" << endl;
    cout << "[2] Delete Staff Record" << endl;
    cout << "[3] Update Staff Record" << endl;
    cout << "[4] Search Staff Record" << endl;
    cout << "[5] Main Menu" << endl;

    cout << "" << endl;
    cout << "Please enter your choice (1, 2, 3, 4, 5): ";
    cin >> adminControl;

    if (adminControl == '1') {
        system("cls");
        AdminAdd(conn);
    }
    else if (adminControl == '2') {
        system("cls");
        AdminDelete(conn);
    }
    else if (adminControl == '3') {
        system("cls");
        AdminUpdate(conn);
    }
    else if (adminControl == '4') {
        system("cls");
        AdminSearch(conn);
    }
    else if (adminControl == '5') {
        system("cls");
        AdminMainMenu(StaffName);
    }
    else {
        cout << "Error!";
        cout << "Press any key to back to main control for admin...";
        system("pause");
        AdminControlMain(conn);
    }
}

void AdminAdd(sql::Connection* conn)
{
    system("cls");
    string StaffID, StaffName, StaffGender, StaffPhone, StaffEmail, StaffPosition, StaffPassword, StaffRole;
    int StaffAge;
    char continueAdd;

    cout << "-------------------" << endl;
    cout << " ADMIN ADD - STAFF " << endl;
    cout << "-------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT StaffID FROM staff ORDER BY StaffID DESC LIMIT 1"
        );
        sql::ResultSet* rs = pstmt->executeQuery();

        int nextID = 1; // default if table is empty

        if (rs->next()) {
            string lastID = rs->getString(1); 
            int num = stoi(lastID.substr(1)); 
            nextID = num + 1;
        }

        if (nextID < 10)
            StaffID = "S00" + to_string(nextID);
        else if (nextID < 100)
            StaffID = "S0" + to_string(nextID);
        else
            StaffID = "S" + to_string(nextID);

        delete rs;
        delete pstmt;
    }
    catch (sql::SQLException& e) {
        cout << "Database Error: " << e.what() << endl;
        system("pause");
        return;
    }

    cout << "New Staff ID: " << StaffID << endl;

    // ===========================
    // GET OTHER STAFF INFO
    // ===========================
    cout << "Name: ";
    cin.ignore();
    getline(cin, StaffName);

    cout << "Gender: ";
    getline(cin, StaffGender);

    cout << "Age: ";
    cin >> StaffAge;
    cin.ignore();

    cout << "Phone Number: ";
    getline(cin, StaffPhone);

    cout << "Email: ";
    getline(cin, StaffEmail);

    cout << "Position: ";
    getline(cin, StaffPosition);

    cout << "Staff Password: ";
    getline(cin, StaffPassword);

    cout << "Staff Role: ";
    getline(cin, StaffRole);

    // ===========================
    // INSERT INTO DATABASE
    // ===========================
    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "INSERT INTO staff (StaffID, StaffName, StaffGender, StaffAge, StaffPhone, StaffEmail, StaffPosition, StaffPassword, StaffRole) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        pstmt->setString(1, StaffID);
        pstmt->setString(2, StaffName);
        pstmt->setString(3, StaffGender);
        pstmt->setInt(4, StaffAge);
        pstmt->setString(5, StaffPhone);
        pstmt->setString(6, StaffEmail);
        pstmt->setString(7, StaffPosition);
        pstmt->setString(8, StaffPassword);
        pstmt->setString(9, StaffRole);

        pstmt->executeUpdate();
        delete pstmt;

        cout << endl << "A new staff record was successfully added!" << endl;
    }
    catch (sql::SQLException& e) {
        cout << "Database Error: " << e.what() << endl;
    }

    cout << endl;
    cout << "Do you want to add another record? (Y/N): ";
    cin >> continueAdd;
    cin.ignore();

    if (continueAdd == 'y' || continueAdd == 'Y') {
        AdminAdd(conn);
    }
    else {
        AdminControlMain(conn);
    }
}

void AdminDelete(sql::Connection* conn)
{
    system("cls");
    cout << "----------------------" << endl;
    cout << "   ADMIN DELETE MENU  " << endl;
    cout << "----------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT StaffID, StaffName, StaffGender, StaffAge, StaffPhone, StaffEmail, StaffPosition, StaffRole "
            "FROM staff"
        );

        sql::ResultSet* res = pstmt->executeQuery();

        cout << "\n*** EXISTING STAFF LIST ***\n";
        cout << "----------------------------------------------------------------------------------------------------------------------\n";
        cout << left
            << setw(10) << "ID"
            << setw(20) << "Name"
            << setw(8) << "Gender"
            << setw(6) << "Age"
            << setw(15) << "Phone"
            << setw(25) << "Email"
            << setw(25) << "Position"
            << setw(10) << "Role" << endl;
        cout << "----------------------------------------------------------------------------------------------------------------------\n";

        while (res->next()) {
            cout << left
                << setw(10) << res->getString("StaffID")
                << setw(20) << res->getString("StaffName")
                << setw(8) << res->getString("StaffGender")
                << setw(6) << res->getInt("StaffAge")
                << setw(15) << res->getString("StaffPhone")
                << setw(25) << res->getString("StaffEmail")
                << setw(25) << res->getString("StaffPosition")
                << setw(10) << res->getString("StaffRole")
                << endl;
        }

        delete pstmt;
        delete res;

        cout << "\nEnter Staff ID to delete: ";
        string StaffID;
        cin >> StaffID;

        // Search the staff before delete
        pstmt = conn->prepareStatement(
            "SELECT StaffID, StaffName, StaffGender, StaffAge, StaffPhone, StaffEmail, StaffPosition, StaffRole "
            "FROM staff WHERE StaffID = ?"
        );
        pstmt->setString(1, StaffID);

        res = pstmt->executeQuery();

        if (!res->next()) {
            cout << "\nNo staff found with ID " << StaffID << endl;
            delete res;
            delete pstmt;
            system("pause");
            AdminControlMain(conn);
            return;
        }

        cout << "\n*** STAFF TO DELETE ***\n";
        cout << "Staff ID: " << res->getString("StaffID") << endl;
        cout << "Name: " << res->getString("StaffName") << endl;
        cout << "Gender: " << res->getString("StaffGender") << endl;
        cout << "Age: " << res->getInt("StaffAge") << endl;
        cout << "Phone: " << res->getString("StaffPhone") << endl;
        cout << "Email: " << res->getString("StaffEmail") << endl;
        cout << "Position: " << res->getString("StaffPosition") << endl;
        cout << "Role: " << res->getString("StaffRole") << endl;

        delete res;
        delete pstmt;

        char confirmDel;
        cout << "\nAre you sure you want to delete this record? [Y/N]: ";
        cin >> confirmDel;

        if (confirmDel == 'Y' || confirmDel == 'y') {
            sql::PreparedStatement* delStmt = conn->prepareStatement(
                "DELETE FROM staff WHERE StaffID = ?"
            );
            delStmt->setString(1, StaffID);
            delStmt->executeUpdate();
            delete delStmt;

            cout << "\nSuccessfully deleted the staff.\n";
            system("pause");
            AdminControlMain(conn);
        }
        else {
            AdminControlMain(conn);
        }
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
    }
}

void AdminUpdate(sql::Connection* conn)
{
    string StaffID;
    char continueUpd, UpdChoice;
    system("cls");
    cout << "----------------------" << endl;
    cout << " ADMIN UPDATE - STAFF " << endl;
    cout << "----------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        cout << "\n===================================================== STAFF LIST =====================================================" << endl;

        sql::Statement* stmt = conn->createStatement();
        sql::ResultSet* listRes = stmt->executeQuery(
            "SELECT StaffID, StaffName, StaffGender, StaffAge, "
            "StaffPhone, StaffEmail, StaffPosition, StaffRole FROM staff"
        );

        cout << left
            << setw(10) << "ID"
            << setw(25) << "NAME"
            << setw(10) << "GENDER"
            << setw(10) << "AGE"
            << setw(15) << "PHONE"
            << setw(25) << "EMAIL"
            << setw(18) << "POSITION"
            << setw(15) << "ROLE" << endl;

        cout << "----------------------------------------------------------------------------------------------------------------------\n" << endl;

        while (listRes->next())
        {
            cout << left
                << setw(10) << listRes->getString("StaffID")
                << setw(25) << listRes->getString("StaffName")
                << setw(10) << listRes->getString("StaffGender")
                << setw(10) << listRes->getInt("StaffAge")
                << setw(15) << listRes->getString("StaffPhone")
                << setw(25) << listRes->getString("StaffEmail")
                << setw(18) << listRes->getString("StaffPosition")
                << setw(15) << listRes->getString("StaffRole") << endl;
        }

        cout << "======================================================================================================================\n";

        delete listRes;
        delete stmt;

        cout << "\nEnter staff ID to update: ";
        cin >> StaffID;

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT StaffName, StaffGender, StaffAge, StaffPhone, StaffEmail, StaffPosition, StaffRole FROM staff WHERE StaffID = ?"
        );
        pstmt->setString(1, StaffID);
        sql::ResultSet* res = pstmt->executeQuery();

        if (!res->next()) {
            cout << "Staff ID not found!" << endl;
            delete res;
            delete pstmt;
            system("pause");
            return;
        }

        cout << "\nCurrent Info:" << endl;
        cout << "Name: " << res->getString("StaffName") << endl;
        cout << "Gender: " << res->getString("StaffGender") << endl;
        cout << "Age: " << res->getInt("StaffAge") << endl;
        cout << "Phone: " << res->getString("StaffPhone") << endl;
        cout << "Email: " << res->getString("StaffEmail") << endl;
        cout << "Position: " << res->getString("StaffPosition") << endl;
        cout << "Role: " << res->getString("StaffRole") << endl;

        delete res;
        delete pstmt;

        cout << "\nWhich field do you want to update?" << endl;
        cout << "[1] Name" << endl;
        cout << "[2] Gender" << endl;
        cout << "[3] Age" << endl;
        cout << "[4] Phone" << endl;
        cout << "[5] Email" << endl;
        cout << "[6] Position" << endl;
        cout << "[7] Password" << endl;
        cout << "[8] Role" << endl;

        cout << "\nYour choice: ";
        cin >> UpdChoice;

        string newValue;
        int newAge;
        string newPassword;

        switch (UpdChoice) {
        case '1':
            cin.ignore();
            cout << "New Name: ";
            getline(cin, newValue);
            break;
        case '2':
            cin.ignore();
            cout << "New Gender: ";
            getline(cin, newValue);
            break;
        case '3':
            cout << "New Age: ";
            cin >> newAge;
            break;
        case '4':
            cin.ignore();
            cout << "New Phone: ";
            getline(cin, newValue);
            break;
        case '5':
            cin.ignore();
            cout << "New Email: ";
            getline(cin, newValue);
            break;
        case '6':
            cin.ignore();
            cout << "New Position: ";
            getline(cin, newValue);
            break;
        case '7':
            cin.ignore();
            cout << "New Password: ";
            char ch;
            while ((ch = _getch()) != 13) {
                newPassword += ch;
                cout << "*";
            }
            newValue = newPassword;
            cout << endl;
            break;
        case '8':
            cin.ignore();
            cout << "New Role: ";
            getline(cin, newValue);
            break;
        default:
            cout << "Invalid choice!" << endl;
            system("pause");
            return;
        }

        // Prepare update statement
        sql::PreparedStatement* updateStmt;
        if (UpdChoice == '3') {
            updateStmt = conn->prepareStatement(
                "UPDATE staff SET StaffAge = ? WHERE StaffID = ?"
            );
            updateStmt->setInt(1, newAge);
        }
        else if (UpdChoice == '7') {
            updateStmt = conn->prepareStatement(
                "UPDATE staff SET StaffPassword = ? WHERE StaffID = ?"
            );
            updateStmt->setString(1, newValue);
        }
        else {
            string column;
            switch (UpdChoice) {
            case '1': column = "StaffName"; break;
            case '2': column = "StaffGender"; break;
            case '4': column = "StaffPhone"; break;
            case '5': column = "StaffEmail"; break;
            case '6': column = "StaffPosition"; break;
            case '8': column = "StaffRole"; break;
            }
            string sql = "UPDATE staff SET " + column + " = ? WHERE StaffID = ?";
            updateStmt = conn->prepareStatement(sql);
            updateStmt->setString(1, newValue);
        }

        updateStmt->setString(2, StaffID);
        updateStmt->executeUpdate();

        cout << "\nSuccessfully Updated!" << endl;
        delete updateStmt;

        cout << "Do you want to continue updating another field? [Y/N]: ";
        cin >> continueUpd;
        if (tolower(continueUpd) == 'y')
            AdminUpdate(conn);
        else
            AdminControlMain(conn);
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
    }
}

void AdminSearch(sql::Connection* conn)
{
    while (true)  
    {
        system("cls");
        cout << "----------------------\n";
        cout << " ADMIN SEARCH - STAFF \n";
        cout << "----------------------\n";

        cout << "\nSearch by: \n";
        cout << "[1] Staff ID\n";
        cout << "[2] Name\n";
        cout << "[3] Gender\n";
        cout << "[4] Age\n";
        cout << "[5] Phone\n";
        cout << "[6] Email\n";
        cout << "[7] Position\n";
        cout << "[8] Role\n";
        cout << "[9] Back to main menu\n";

        int choice;
        cout << "\nYour choice >> ";
        cin >> choice;

        if (choice == 9)
        {
            AdminControlMain(conn);
            return;
        }

        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* ps;
        sql::ResultSet* rs;

        string input;
        int age;

        switch (choice)
        {
        case 1: // Staff ID
            cout << "Enter Staff ID: ";
            cin >> input;
            ps = conn->prepareStatement(
                "SELECT StaffID, StaffName, StaffGender, StaffAge, "
                "StaffPhone, StaffEmail, StaffPosition, StaffRole "
                "FROM staff WHERE StaffID = ?"
            );
            ps->setString(1, input);
            break;

        case 2: // Name
            cout << "Enter Name: ";
            cin.ignore();
            getline(cin, input);
            ps = conn->prepareStatement(
                "SELECT StaffID, StaffName, StaffGender, StaffAge, "
                "StaffPhone, StaffEmail, StaffPosition, StaffRole "
                "FROM staff WHERE StaffName LIKE ?"
            );
            ps->setString(1, "%" + input + "%");
            break;

        case 3: // Gender
            cout << "Enter Gender (Male/Female): ";
            cin >> input;
            ps = conn->prepareStatement(
                "SELECT StaffID, StaffName, StaffGender, StaffAge, "
                "StaffPhone, StaffEmail, StaffPosition, StaffRole "
                "FROM staff WHERE StaffGender = ?"
            );
            ps->setString(1, input);
            break;

        case 4: // Age
            cout << "Enter Age: ";
            cin >> age;
            ps = conn->prepareStatement(
                "SELECT StaffID, StaffName, StaffGender, StaffAge, "
                "StaffPhone, StaffEmail, StaffPosition, StaffRole "
                "FROM staff WHERE StaffAge = ?"
            );
            ps->setInt(1, age);
            break;

        case 5: // Phone
            cout << "Enter Phone Number: ";
            cin >> input;
            ps = conn->prepareStatement(
                "SELECT StaffID, StaffName, StaffGender, StaffAge, "
                "StaffPhone, StaffEmail, StaffPosition, StaffRole "
                "FROM staff WHERE StaffPhone LIKE ?"
            );
            ps->setString(1, "%" + input + "%");
            break;

        case 6: // Email
            cout << "Enter Email: ";
            cin >> input;
            ps = conn->prepareStatement(
                "SELECT StaffID, StaffName, StaffGender, StaffAge, "
                "StaffPhone, StaffEmail, StaffPosition, StaffRole "
                "FROM staff WHERE StaffEmail LIKE ?"
            );
            ps->setString(1, "%" + input + "%");
            break;

        case 7: // Position
            cout << "Enter Position: ";
            cin.ignore();
            getline(cin, input);
            ps = conn->prepareStatement(
                "SELECT StaffID, StaffName, StaffGender, StaffAge, "
                "StaffPhone, StaffEmail, StaffPosition, StaffRole "
                "FROM staff WHERE StaffPosition LIKE ?"
            );
            ps->setString(1, "%" + input + "%");
            break;

        case 8: // Role
            cout << "Enter Role (Admin/Staff): ";
            cin >> input;
            ps = conn->prepareStatement(
                "SELECT StaffID, StaffName, StaffGender, StaffAge, "
                "StaffPhone, StaffEmail, StaffPosition, StaffRole "
                "FROM staff WHERE StaffRole LIKE ?"
            );
            ps->setString(1, "%" + input + "%");
            break;

        case 9:
            AdminControlMain(conn);
            return;

        default:
            cout << "Invalid choice!\n";
            return;
        }

        rs = ps->executeQuery();
        bool found = false;

        while (rs->next())
        {
            found = true;
            cout << "\n----------------------\n";
            cout << "Staff ID: " << rs->getString("StaffID") << endl;
            cout << "Name: " << rs->getString("StaffName") << endl;
            cout << "Gender: " << rs->getString("StaffGender") << endl;
            cout << "Age: " << rs->getInt("StaffAge") << endl;
            cout << "Phone: " << rs->getString("StaffPhone") << endl;
            cout << "Email: " << rs->getString("StaffEmail") << endl;
            cout << "Position: " << rs->getString("StaffPosition") << endl;
            cout << "Role: " << rs->getString("StaffRole") << endl;
        }

        if (!found)
            cout << "\nNo record found!\n";

        delete rs;
        delete ps;

        cout << "\nSearch again? (Y/N): ";
        char again;
        cin >> again;
        if (again != 'Y' && again != 'y')
        {
            AdminControlMain(conn);
            return;
        }
    }
}

//display list of staffs for admin
void AdminDisplay(sql::Connection* conn, string StaffName)
{
    system("cls");
    cout << "--------------" << endl;
    cout << " STAFF RECORD " << endl;
    cout << "--------------" << endl;
    cout << "Here is the record of staff:\n" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::Statement* stmt = conn->createStatement();
        sql::ResultSet* res = stmt->executeQuery(
            "SELECT StaffID, StaffName, StaffGender, StaffAge, StaffPhone, StaffEmail, StaffPosition, StaffRole FROM staff"
        );

        cout << string(120, '-') << endl; 
        cout << left
            << setw(12) << "Staff ID"
            << setw(20) << "Name"
            << setw(10) << "Gender"
            << setw(6) << "Age"
            << setw(15) << "Phone"
            << setw(25) << "Email"
            << setw(20) << "Position"
            << setw(10) << "Role"
            << endl;
        cout << string(120, '-') << endl;

        while (res->next()) {
            cout << left
                << setw(12) << res->getString("StaffID").c_str()
                << setw(20) << res->getString("StaffName").c_str()
                << setw(10) << res->getString("StaffGender").c_str()
                << setw(6) << res->getInt("StaffAge")
                << setw(15) << res->getString("StaffPhone").c_str()
                << setw(25) << res->getString("StaffEmail").c_str()
                << setw(20) << res->getString("StaffPosition").c_str()
                << setw(10) << res->getString("StaffRole").c_str()
                << endl;
        }
        cout << string(120, '-') << endl;

        delete res;
        delete stmt;
    }
    catch (sql::SQLException& e) {
        cout << "Query error: " << e.what() << endl;
    }

    system("pause");
    AdminMainMenu(StaffName);
}

void AdminReportMain(sql::Connection* conn, const string& StaffName)
{
    while (true)
    {
        system("cls");
        ShowTime();

        int adminReport;
        string countStaff;

        cout << "-----------------------------\n";
        cout << " REPORT GENERATION FOR ADMIN \n";
        cout << "-----------------------------\n";

        // TOTAL STAFF
        try {
            sql::Driver* driver = get_driver_instance();
            sql::Connection* conn = driver->connect(server, username, password);
            conn->setSchema("bloodbankmanagementdb");

            unique_ptr<sql::PreparedStatement> pstmt(
                conn->prepareStatement("SELECT COUNT(*) FROM staff"));

            unique_ptr<sql::ResultSet> rs(pstmt->executeQuery());

            if (rs->next())
                countStaff = rs->getString(1);
        }
        catch (sql::SQLException& e) {
            cout << "SQL Error: " << e.what() << endl;
            system("pause");
            AdminMainMenu(StaffName);
            return;
        }

        cout << "Total number of staff in the system: " << countStaff << endl;

        // SELECTION MENU
        cout << "\nWhich attribute do you want to generate as report?\n";
        cout << "[1] Gender\n";
        cout << "[2] Position\n";
        cout << "[3] Age\n";
        cout << "[4] Back to Main Menu\n";
        cout << "Your choice: ";
        cin >> adminReport;

        if (adminReport == 4) {
            AdminMainMenu(StaffName);
            return;
        }

        // Variables to store report data
        string male, female, doc, nurse, labtech, a20, a30, a40, a50;

        // REPORT 1: GENDER
        if (adminReport == 1)
        {
            try {
                sql::Driver* driver = get_driver_instance();
                sql::Connection* conn = driver->connect(server, username, password);
                conn->setSchema("bloodbankmanagementdb");

                unique_ptr<sql::PreparedStatement> pstmt(
                    conn->prepareStatement(
                        "SELECT "
                        "SUM(CASE WHEN StaffGender = 'Male' THEN 1 ELSE 0 END), "
                        "SUM(CASE WHEN StaffGender = 'Female' THEN 1 ELSE 0 END) "
                        "FROM staff"
                    )
                );

                unique_ptr<sql::ResultSet> rs(pstmt->executeQuery());

                if (rs->next()) {
                    male = rs->getString(1);
                    female = rs->getString(2);
                }
            }
            catch (sql::SQLException& e) {
                cout << "SQL Error: " << e.what() << endl;
                system("pause");
                continue;
            }

            system("cls");
            ShowTime();
            cout << "\nStaff count by gender:\n";
            cout << "Male = " << male << endl;
            cout << "Female = " << female << endl;

            int arrVal[2] = { stoi(male), stoi(female) };
            string labels[2] = { "Male", "Female" };

            cout << endl;
            cout << "****************************************************\n";
            cout << "|         Graph (GENDER VS NUMBER OF STAFF)        |\n";
            cout << "****************************************************\n";
            cout << endl;

            for (int i = 0; i < 2; i++) {
                cout << setw(8) << left << labels[i] << "|";
                for (int s = 0; s < arrVal[i]; s++) cout << "*";
                if (arrVal[i] != 0) cout << " " << arrVal[i];
                cout << endl;
            }
        }

        // REPORT 2: POSITION
        else if (adminReport == 2)
        {
            try {
                sql::Driver* driver = get_driver_instance();
                sql::Connection* conn = driver->connect(server, username, password);
                conn->setSchema("bloodbankmanagementdb");

                unique_ptr<sql::PreparedStatement> pstmt(
                    conn->prepareStatement(
                        "SELECT "
                        "SUM(CASE WHEN StaffPosition = 'Doctor' THEN 1 ELSE 0 END),"
                        "SUM(CASE WHEN StaffPosition = 'Nurse' THEN 1 ELSE 0 END),"
                        "SUM(CASE WHEN StaffPosition = 'Lab Technician' THEN 1 ELSE 0 END) "
                        "FROM staff"
                    )
                );

                unique_ptr<sql::ResultSet> rs(pstmt->executeQuery());

                if (rs->next()) {
                    doc = rs->getString(1);
                    nurse = rs->getString(2);
                    labtech = rs->getString(3);
                }
            }
            catch (sql::SQLException& e) {
                cout << "SQL Error: " << e.what() << endl;
                system("pause");
                continue;
            }

            system("cls");
            ShowTime();
            cout << "\nStaff count by position:\n";
            cout << "Doctor = " << doc << endl;
            cout << "Nurse = " << nurse << endl;
            cout << "Lab Technician = " << labtech << endl;

            int arrVal[3] = { stoi(doc), stoi(nurse), stoi(labtech) };
            string labels[3] = { "Doctor", "Nurse", "Lab Technician" };

            cout << endl;
            cout << "******************************************************\n";
            cout << "|         Graph (POSITION VS NUMBER OF STAFF)        |\n";
            cout << "******************************************************\n";
            cout << endl;

            for (int i = 0; i < 3; i++) {
                cout << setw(10) << left << labels[i] << "|";
                for (int s = 0; s < arrVal[i]; s++) cout << "*";
                if (arrVal[i] != 0) cout << " " << arrVal[i];
                cout << endl;
            }
        }

        // REPORT 3: AGE GROUPS
        else if (adminReport == 3)
        {
            sql::Driver* driver = get_driver_instance();
            sql::Connection* conn = driver->connect(server, username, password);
            conn->setSchema("bloodbankmanagementdb");

            auto runCount = [&](string q, string& out) {
                unique_ptr<sql::PreparedStatement> pstmt(conn->prepareStatement(q));
                unique_ptr<sql::ResultSet> rs(pstmt->executeQuery());
                if (rs->next()) out = rs->getString(1);
                };

            try {
                runCount("SELECT COUNT(*) FROM staff WHERE StaffAge >=20 AND StaffAge < 30", a20);
                runCount("SELECT COUNT(*) FROM staff WHERE StaffAge >=30 AND StaffAge < 40", a30);
                runCount("SELECT COUNT(*) FROM staff WHERE StaffAge >=40 AND StaffAge < 50", a40);
                runCount("SELECT COUNT(*) FROM staff WHERE StaffAge >=50 AND StaffAge < 60", a50);
            }
            catch (sql::SQLException& e) {
                cout << "SQL Error: " << e.what() << endl;
                system("pause");
                continue;
            }

            system("cls");
            ShowTime();

            cout << "\nStaff count by age group:\n";
            cout << "20�29 = " << a20 << endl;
            cout << "30�39 = " << a30 << endl;
            cout << "40�49 = " << a40 << endl;
            cout << "50�59 = " << a50 << endl;

            int arrVal[4] = { stoi(a20), stoi(a30), stoi(a40), stoi(a50) };
            string labels[4] = { "20-29", "30-39", "40-49", "50-59" };

            cout << endl;
            cout << "*************************************************\n";
            cout << "|         Graph (AGE VS NUMBER OF STAFF)        |\n";
            cout << "*************************************************\n";
            cout << endl;

            for (int i = 0; i < 4; i++) {
                cout << setw(8) << left << labels[i] << "|";
                for (int s = 0; s < arrVal[i]; s++) cout << "*";
                if (arrVal[i] != 0) cout << " " << arrVal[i];
                cout << endl;
            }
        }

        char exportFile;
        cout << "\nDo you want to export this report to a TXT file? (Y/N): ";
        cin >> exportFile;

        if (exportFile == 'Y' || exportFile == 'y')
        {
            // Get current time and date
            time_t t = time(0);
            tm ltm;
            localtime_s(&ltm, &t);

            // Build filename with timestamp
            string filename = "AdminReport_";
            filename += to_string(1900 + ltm.tm_year);
            filename += (ltm.tm_mon + 1 < 10 ? "0" : "") + to_string(ltm.tm_mon + 1);
            filename += (ltm.tm_mday < 10 ? "0" : "") + to_string(ltm.tm_mday);
            filename += "_";
            filename += (ltm.tm_hour < 10 ? "0" : "") + to_string(ltm.tm_hour);
            filename += (ltm.tm_min < 10 ? "0" : "") + to_string(ltm.tm_min);
            filename += (ltm.tm_sec < 10 ? "0" : "") + to_string(ltm.tm_sec);
            filename += ".txt";

            ofstream reportFile(filename);
            if (!reportFile.is_open())
            {
                cout << "Failed to create report file!" << endl;
            }
            else
            {
                // Date & Time header
                char buffer[100];
                strftime(buffer, sizeof(buffer), "%A, %d/%m/%Y %I:%M:%S %p", &ltm);
                reportFile << "-----------------------------\n";
                reportFile << " REPORT GENERATION FOR ADMIN \n";
                reportFile << "-----------------------------\n";
                reportFile << "Report generated on: " << buffer << "\n\n";

                // Total staff
                reportFile << "Total number of staff in the system: " << countStaff << "\n\n";

                if (adminReport == 1) // Gender
                {
                    reportFile << "Staff count by gender:\n";
                    reportFile << "Male = " << male << endl;
                    reportFile << "Female = " << female << endl << endl;

                    int arrVal[2] = { stoi(male), stoi(female) };
                    string labels[2] = { "Male", "Female" };

                    reportFile << "****************************************************\n";
                    reportFile << "|         Graph (GENDER VS NUMBER OF STAFF)        |\n";
                    reportFile << "****************************************************\n\n";

                    for (int i = 0; i < 2; i++) {
                        reportFile << setw(8) << left << labels[i] << "|";
                        for (int s = 0; s < arrVal[i]; s++) reportFile << "*";
                        if (arrVal[i] != 0) reportFile << " " << arrVal[i];
                        reportFile << endl;
                    }
                    reportFile << "\n";
                }
                else if (adminReport == 2) // Position
                {
                    reportFile << "Staff count by position:\n";
                    reportFile << "Doctor = " << doc << endl;
                    reportFile << "Nurse = " << nurse << endl;
                    reportFile << "Lab Technician = " << labtech << endl << endl;

                    int arrVal[3] = { stoi(doc), stoi(nurse), stoi(labtech) };
                    string labels[3] = { "Doctor", "Nurse", "Lab Technician" };

                    reportFile << "******************************************************\n";
                    reportFile << "|         Graph (POSITION VS NUMBER OF STAFF)        |\n";
                    reportFile << "******************************************************\n\n";

                    for (int i = 0; i < 3; i++) {
                        reportFile << setw(10) << left << labels[i] << "|";
                        for (int s = 0; s < arrVal[i]; s++) reportFile << "*";
                        if (arrVal[i] != 0) reportFile << " " << arrVal[i];
                        reportFile << endl;
                    }
                    reportFile << "\n";
                }
                else if (adminReport == 3) // Age
                {
                    reportFile << "Staff count by age group:\n";
                    reportFile << "20�29 = " << a20 << endl;
                    reportFile << "30�39 = " << a30 << endl;
                    reportFile << "40�49 = " << a40 << endl;
                    reportFile << "50�59 = " << a50 << endl << endl;

                    int arrVal[4] = { stoi(a20), stoi(a30), stoi(a40), stoi(a50) };
                    string labels[4] = { "20-29", "30-39", "40-49", "50-59" };

                    reportFile << "*************************************************\n";
                    reportFile << "|         Graph (AGE VS NUMBER OF STAFF)        |\n";
                    reportFile << "*************************************************\n\n";

                    for (int i = 0; i < 4; i++) {
                        reportFile << setw(8) << left << labels[i] << "|";
                        for (int s = 0; s < arrVal[i]; s++) reportFile << "*";
                        if (arrVal[i] != 0) reportFile << " " << arrVal[i];
                        reportFile << endl;
                    }
                    reportFile << "\n";
                }

                reportFile.close();
                cout << "Report exported successfully: " << filename << endl;
            }
        }

        char again;
        cout << "\nDo you want to continue viewing report? (Y/N): ";
        cin >> again;

        if (again == 'N' || again == 'n')
        {
            AdminMainMenu(StaffName);
            return;
        }
    }
}

void StaffLogin()
{
    system("cls");
    cout << "----------------" << endl;
    cout << " LOGIN AS STAFF " << endl;
    cout << "----------------" << endl;
    cout << endl;

    cout << "Enter Staff ID: ";
    cin >> StaffID;

    cout << "Enter Password: ";
    string StaffPassword;
    char ch;
    while ((ch = _getch()) != 13)
    {
        StaffPassword += ch;
        cout << "*";
    }

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT StaffID, StaffName FROM staff WHERE StaffID = ? AND StaffPassword = ?"
        );
        pstmt->setString(1, StaffID);
        pstmt->setString(2, StaffPassword);

        sql::ResultSet* res = pstmt->executeQuery();

        if (res->next())
        {
            StaffID = res->getString("StaffID");
            StaffName = res->getString("StaffName");

            delete res;
            delete pstmt;

            system("cls");
            StaffMainMenu(StaffID, StaffName);
        }
        else {
            delete res;
            delete pstmt;

            char c;
            cout << "\nInvalid username or password. Retry? (Y/N): ";
            cin >> c;
            if (c == 'y' || c == 'Y')
                StaffLogin();
            else
                MainLogin();
        }
    }
    catch (sql::SQLException& e) {
        cout << "Error: " << e.what() << endl;
    }
}

void StaffMainMenu(string id, string name)
{
    char StaffMainChoice;
    cout << "-----------------" << endl;
    cout << " STAFF MAIN MENU " << endl;
    cout << "-----------------" << endl;

    cout << "Welcome, staff " << name << "!" << endl;
    cout << endl;

    cout << "[1] Control Menu" << endl;
    cout << "[2] Recent Donation Records" << endl;
    cout << "[3] Report Generation" << endl;
    cout << "[4] Account Information" << endl;
    cout << "[5] Back to main menu" << endl;
    cout << "\nYour choice (1 - 5): ";
    cin >> StaffMainChoice;

    switch (StaffMainChoice)
    {
    case '1':
        StaffControlMain();
        break;

    case '2':
        RecentDonation(conn, StaffName);
        break;

    case '3':
        system("cls");
        StaffReport(conn, StaffID, StaffName);
        break;

    case '4':
        system("cls");
        StaffAccount(id, conn, StaffID, StaffName);
        break;

    case '5':
        system("CLS");
        main();

    default:
        cout << "Error! Invalid choice! " << endl;
        system("pause");
        StaffMainMenu(id, name);
    }
}

void StaffControlMain()
{
    char StaffControl;
    system("cls");
    cout << "--------------------" << endl;
    cout << " STAFF CONTROL MENU " << endl;
    cout << "--------------------" << endl;
    cout << "Welcome, staff! What would you like to do?" << endl;
    cout << endl;

    cout << "[1] Add Record" << endl;
    cout << "[2] Delete Record" << endl;
    cout << "[3] Update Record" << endl;
    cout << "[4] Search Record" << endl;
    cout << "[5] Main Menu" << endl;

    cout << "\nPlease enter your choice (1, 2, 3, 4, 5): ";
    cin >> StaffControl;

    switch (StaffControl)
    {
    case '1':
        StaffControlAdd();
        break;

    case '2':
        system("cls");
        StaffControlDelete();
        break;

    case '3':
        system("cls");
        StaffControlUpdate();
        break;

    case '4':
        system("cls");
        StaffControlSearch();
        break;

    case '5':
        system("cls");
        StaffMainMenu(StaffID, StaffName);
        break;

    default:
        cout << "Invalid choice!" << endl;
        StaffControlMain();
    }
}

void StaffControlAdd()
{
    int StaffAdd;
    system("cls");

    cout << "-----------------" << endl;
    cout << " ADD RECORD MENU " << endl;
    cout << "-----------------" << endl;

    cout << "[1] Add Record of Donors" << endl;
    cout << "[2] Add Record of Blood Stock" << endl;
    cout << "[3] Add Record of Donation" << endl;
    cout << "[4] Main Menu" << endl;

    cout << "\nPlease enter your choice: ";
    cin >> StaffAdd;

    switch (StaffAdd) {
    case 1:
        AddDonorMenu(conn);
        break;

    case 2:
        AddBloodMenu(conn);
        break;

    case 3:
        AddDonationMenu(conn);
        break;
     case 4:
        StaffControlMain();
        break;

    default:
        cout << "Invalid choice!" << endl;
        system("pause");
        StaffControlAdd();
        break;
    }
}

void AddDonorMenu(sql::Connection* conn) {
    system("cls");

    string DonorID, DonorName, DonorGender, DonorDOB, DonorAddress, DonorPhone, DonorEmail, DonorBloodType, DonorPassword;
    int DonorAge;
    double DonorHeight, DonorWeight;

    int d_year, d_month, d_day;
    string DOB;
    char AddDonor;

    cout << "---------------------" << endl;
    cout << " ADD RECORDS - DONOR " << endl;
    cout << "---------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT DonorID FROM Donor ORDER BY DonorID DESC LIMIT 1"
        );

        sql::ResultSet* rs = pstmt->executeQuery();

        int nextID = 1;

        if (rs->next()) {
            string lastID = rs->getString(1);   
            int num = stoi(lastID.substr(1));   
            nextID = num + 1;
        }

        if (nextID < 10)
            DonorID = "D00" + to_string(nextID);
        else if (nextID < 100)
            DonorID = "D0" + to_string(nextID);
        else
            DonorID = "D" + to_string(nextID);

        delete rs;
        delete pstmt;
    }
    catch (sql::SQLException& e) {
        cout << "Database Error: " << e.what() << endl;
        system("pause");
        return;
    }

    cout << "New Donor ID: " << DonorID << endl << endl;


    cout << "Name: ";
    cin.ignore();
    getline(cin, DonorName);

    cout << "Gender (Male/Female): ";
    cin >> DonorGender;

    cout << "Date of Birth (YYYY-MM-DD): ";
    cin >> d_year >> d_month >> d_day;

    DOB = to_string(d_year) + "-" + to_string(d_month) + "-" + to_string(d_day);
    DonorDOB = DOB;

    DonorAge = calculateAge(d_year, d_month, d_day);

    cin.ignore();
    cout << "Address: ";
    getline(cin, DonorAddress);

    cout << "Blood Type (A/B/AB/O): ";
    cin >> DonorBloodType;

    cout << "Height (cm): ";
    cin >> DonorHeight;

    cout << "Weight (kg): ";
    cin >> DonorWeight;

    cin.ignore();
    cout << "Phone Number: ";
    getline(cin, DonorPhone);

    cout << "Email: ";
    getline(cin, DonorEmail);

    // Password
    DonorPassword = "";
    cout << "Password: ";
    char ch;
    while ((ch = _getch()) != 13) {
        DonorPassword += ch;
        cout << "*";
    }
    cout << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "INSERT INTO Donor "
            "(DonorID, DonorName, DonorGender, DonorAge, DonorDOB, DonorAddress, DonorBloodType, DonorHeight, DonorWeight, DonorPhone, DonorEmail, DonorPassword) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        pstmt->setString(1, DonorID);
        pstmt->setString(2, DonorName);
        pstmt->setString(3, DonorGender);
        pstmt->setInt(4, DonorAge);
        pstmt->setString(5, DonorDOB);
        pstmt->setString(6, DonorAddress);
        pstmt->setString(7, DonorBloodType);
        pstmt->setDouble(8, DonorHeight);
        pstmt->setDouble(9, DonorWeight);
        pstmt->setString(10, DonorPhone);
        pstmt->setString(11, DonorEmail);
        pstmt->setString(12, DonorPassword);

        pstmt->execute();
        delete pstmt;

        cout << "\nDonor successfully added to the database!" << endl;
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
    }


    cout << "Do you want to continue adding records? [Y/N]: ";
    cin >> AddDonor;
    cin.ignore();

    if (AddDonor == 'y' || AddDonor == 'Y') {
        AddDonorMenu(conn);
    }
    else {
        system("cls");
        StaffControlAdd();
    }
}

void AddBloodMenu(sql::Connection* conn)
{
    system("cls");
    string StockID, BloodType, ExpiryDate, DonationID;
    int Quantity;

    char AddBlood;

    cout << "---------------------------" << endl;
    cout << " ADD RECORDS - BLOOD STOCK " << endl;
    cout << "---------------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::Statement* stmt = conn->createStatement();
        sql::ResultSet* rs = stmt->executeQuery(
            "SELECT IFNULL(MAX(CAST(SUBSTRING(StockID,3) AS UNSIGNED)),0)+1 AS NextID FROM BloodStock"
        );

        int stockNum = 1;
        if (rs->next())
            stockNum = rs->getInt("NextID");

        if (stockNum < 10) StockID = "BS00" + to_string(stockNum);
        else if (stockNum < 100) StockID = "BS0" + to_string(stockNum);
        else StockID = "BS" + to_string(stockNum);

        delete rs;
        delete stmt;

        cout << "New Stock ID: " << StockID << endl;
    }
    catch (sql::SQLException& e) {
        cout << "Database Error: " << e.what() << endl;
        return;
    }

    cout << "Blood Type (A/B/AB/O): ";
    cin >> BloodType;

    cout << "Quantity: ";
    cin >> Quantity;

    int y, m, d;
    cout << "Expiry Date (YYYY-MM-DD): ";
    cin >> y >> m >> d;
    ExpiryDate = to_string(y) + "-" + to_string(m) + "-" + to_string(d);

    cout << "Donation ID (e.g. DN***): ";
    cin >> DonationID;

    string Status = "Available";

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "INSERT INTO BloodStock (StockID, BloodType, Quantity, DateReceived, ExpiryDate, Status, DonationID) "
            "VALUES (?, ?, ?, CURRENT_DATE(), ?, ?, ?)"
        );

        pstmt->setString(1, StockID);
        pstmt->setString(2, BloodType);
        pstmt->setInt(3, Quantity);
        pstmt->setString(4, ExpiryDate);
        pstmt->setString(5, Status);
        pstmt->setString(6, DonationID);

        pstmt->executeUpdate();
        cout << "\nBlood stock successfully added to the database." << endl;

        delete pstmt;
    }
    catch (sql::SQLException& e)
    {
        cout << "SQL Error: " << e.what() << endl;
    }

    cout << "Do you want to continue adding records? [Y/N]: ";
    cin >> AddBlood;
    if (AddBlood == 'y' || AddBlood == 'Y')
        AddBloodMenu(conn);
    else
        StaffControlAdd();
}

void AddDonationMenu(sql::Connection* conn)
{
    system("cls");
    string DonationID, DonationDate, BloodType, DonorID, StaffID;
    double BloodVolume;
    char AddDonation;

    cout << "------------------------" << endl;
    cout << " ADD RECORDS - DONATION " << endl;
    cout << "------------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::Statement* stmt = conn->createStatement();
        sql::ResultSet* rs = stmt->executeQuery(
            "SELECT IFNULL(MAX(CAST(SUBSTRING(DonationID,3) AS UNSIGNED)),0)+1 AS NextID FROM Donation"
        );

        int dID = 1;
        if (rs->next())
            dID = rs->getInt("NextID");

        if (dID < 10) DonationID = "DN00" + to_string(dID);
        else if (dID < 100) DonationID = "DN0" + to_string(dID);
        else DonationID = "DN" + to_string(dID);

        delete rs;
        delete stmt;

        cout << "New Donation ID: " << DonationID << endl;
    }
    catch (sql::SQLException& e) {
        cout << "Database Error: " << e.what() << endl;
        return;
    }

    int y, m, d;
    cout << "Donation Date (YYYY-MM-DD): ";
    cin >> y >> m >> d;
    DonationDate = to_string(y) + "-" + to_string(m) + "-" + to_string(d);

    cout << "Donation Volume: ";
    cin >> BloodVolume;

    cout << "Blood Type (A/B/AB/O): ";
    cin >> BloodType;

    cout << "Donor ID (e.g.D***): ";
    cin >> DonorID;

    cout << "Staff ID (e.g. S***): ";
    cin >> StaffID;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "INSERT INTO Donation (DonationID, DonationDate, BloodVolume, BloodType, DonorID, StaffID) "
            "VALUES (?, ?, ?, ?, ?, ?)"
        );
        pstmt->setString(1, DonationID);
        pstmt->setString(2, DonationDate);
        pstmt->setDouble(3, BloodVolume);
        pstmt->setString(4, BloodType);
        pstmt->setString(5, DonorID);
        pstmt->setString(6, StaffID);
        pstmt->executeUpdate();
        delete pstmt;

        // ===== Update LastDonationDate for donor =====
        pstmt = conn->prepareStatement(
            "UPDATE Donor SET LastDonationDate = ? WHERE DonorID = ?"
        );
        pstmt->setString(1, DonationDate);
        pstmt->setString(2, DonorID);
        pstmt->executeUpdate();
        delete pstmt;

        // ===== Update Reward Points =====
        pstmt = conn->prepareStatement(
            "UPDATE RewardPoints SET TotalPoints = TotalPoints + 10 WHERE DonorID = ?"
        );
        pstmt->setString(1, DonorID);
        int rows = pstmt->executeUpdate();
        delete pstmt;

        // ===== If no reward record exists, create one =====
        if (rows == 0) {
            // Generate RewardID
            sql::Statement* stmt = conn->createStatement();
            sql::ResultSet* rs = stmt->executeQuery(
                "SELECT IFNULL(MAX(CAST(SUBSTRING(RewardID,3) AS UNSIGNED)),0)+1 AS NextID FROM RewardPoints"
            );

            int nextID = 1;
            if (rs->next()) nextID = rs->getInt("NextID");

            string RewardID;
            if (nextID < 10) RewardID = "R00" + to_string(nextID);
            else if (nextID < 100) RewardID = "R0" + to_string(nextID);
            else RewardID = "R" + to_string(nextID);

            delete rs;
            delete stmt;

            pstmt = conn->prepareStatement(
                "INSERT INTO RewardPoints (RewardID, DonorID, TotalPoints, RewardLevel) "
                "VALUES (?, ?, 10, 'Bronze')"
            );
            pstmt->setString(1, RewardID);
            pstmt->setString(2, DonorID);
            pstmt->executeUpdate();
            delete pstmt;
        }

        // ===== Update Reward Level automatically =====
        pstmt = conn->prepareStatement(
            "UPDATE RewardPoints SET RewardLevel = CASE "
            "WHEN TotalPoints >= 200 THEN 'Gold' "
            "WHEN TotalPoints >= 100 THEN 'Silver' "
            "ELSE 'Bronze' "
            "END WHERE DonorID = ?"
        );
        pstmt->setString(1, DonorID);
        pstmt->executeUpdate();
        delete pstmt;

        cout << "\nDonation successfully added and reward points updated." << endl;
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
    }

    cout << "Do you want to continue adding records? [Y/N]: ";
    cin >> AddDonation;
    if (AddDonation == 'y' || AddDonation == 'Y')
        AddDonationMenu(conn);
    else
        StaffControlAdd();
}

void StaffControlDelete()
{
    int StaffDelete;
    system("cls");

    cout << "--------------------" << endl;
    cout << " DELETE RECORD MENU " << endl;
    cout << "--------------------" << endl;

    cout << "[1] Delete Record of Donors" << endl;
    cout << "[2] Delete Record of Blood Stock" << endl;
    cout << "[3] Delete Record of Donation" << endl;
    cout << "[4] Main Menu" << endl;

    cout << "\nPlease enter your choice: ";
    cin >> StaffDelete;

    switch (StaffDelete) {
    case 1:
        DeleteDonor(conn);
        break;

    case 2:
        DeleteBlood(conn);
        break;

    case 3:
        DeleteDonation(conn);
        break;

    case 4:
        StaffControlMain();
        break;

    default:
        cout << "Invalid choice!" << endl;
        system("pause");
        StaffControlDelete();
        break;
    }
}

void DeleteDonor(sql::Connection* conn)
{
    string DonorID;
    char confirmDel, continueDel;
    system("cls");

    cout << "-----------------------" << endl;
    cout << " DELETE RECORD - DONOR " << endl;
    cout << "-----------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::Statement* stmt = conn->createStatement();
        sql::ResultSet* rs = stmt->executeQuery(
            "SELECT DonorID, DonorName, DonorBloodType, DonorPhone FROM Donor"
        );

        cout << "\n=========================== ALL DONORS ===========================" << endl;
        cout << left
            << setw(10) << "ID"
            << setw(25) << "NAME"
            << setw(15) << "BLOOD TYPE"
            << setw(20) << "PHONE" << endl;
        cout << "-------------------------------------------------------------------" << endl;

        while (rs->next()) {
            cout << left
                << setw(10) << rs->getString("DonorID")
                << setw(25) << rs->getString("DonorName")
                << setw(15) << rs->getString("DonorBloodType")
                << setw(20) << rs->getString("DonorPhone") << endl;
        }
        cout << "===================================================================\n";

        delete rs;
        delete stmt;

        cout << "\nEnter Donor ID to delete: ";
        cin >> DonorID;

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT * FROM Donor WHERE DonorID = ?"
        );
        pstmt->setString(1, DonorID);
        sql::ResultSet* res = pstmt->executeQuery();

        if (!res->next()) {
            cout << "\nNo donor found with ID " << DonorID << endl;
            delete res;
            delete pstmt;
            system("pause");
            StaffControlDelete();
            return;
        }

        cout << "\nHere's the record found:\n" << endl;
        cout << "Donor ID: " << res->getString("DonorID") << endl;
        cout << "Name: " << res->getString("DonorName") << endl;
        cout << "Gender: " << res->getString("DonorGender") << endl;
        cout << "Age: " << res->getInt("DonorAge") << endl;
        cout << "Date of Birth: " << res->getString("DonorDOB") << endl;
        cout << "Address: " << res->getString("DonorAddress") << endl;
        cout << "Blood Type: " << res->getString("DonorBloodType") << endl;
        cout << "Height: " << res->getDouble("DonorHeight") << endl;
        cout << "Weight: " << res->getDouble("DonorWeight") << endl;
        cout << "Phone: " << res->getString("DonorPhone") << endl;
        cout << "Email: " << res->getString("DonorEmail") << endl;
        cout << "Last Donation Date: " << res->getString("LastDonationDate") << endl;

        delete res;
        delete pstmt;

        cout << "\nAre you sure you want to delete this record [Y/N]: ";
        cin >> confirmDel;

        if (confirmDel == 'Y' || confirmDel == 'y')
        {
            // ===== 1. Delete BloodStock =====
            pstmt = conn->prepareStatement(
                "DELETE FROM BloodStock WHERE DonationID IN "
                "(SELECT DonationID FROM Donation WHERE DonorID = ?)"
            );
            pstmt->setString(1, DonorID);
            pstmt->executeUpdate();
            delete pstmt;

            // ===== 2. Delete Donation =====
            pstmt = conn->prepareStatement(
                "DELETE FROM Donation WHERE DonorID = ?"
            );
            pstmt->setString(1, DonorID);
            pstmt->executeUpdate();
            delete pstmt;

            // ===== 3. Delete RewardPoints =====
            pstmt = conn->prepareStatement(
                "DELETE FROM RewardPoints WHERE DonorID = ?"
            );
            pstmt->setString(1, DonorID);
            pstmt->executeUpdate();
            delete pstmt;

            // ===== 4. Delete Donor =====
            pstmt = conn->prepareStatement(
                "DELETE FROM Donor WHERE DonorID = ?"
            );
            pstmt->setString(1, DonorID);
            pstmt->executeUpdate();
            delete pstmt;

            cout << "\nSuccessfully deleted the donor!" << endl;

            cout << "Do you want to continue deleting? [Y/N]: ";
            cin >> continueDel;

            if (continueDel == 'Y' || continueDel == 'y')
                DeleteDonor(conn);
            else
                StaffControlDelete();
        }
        else {
            cout << "\nDeletion cancelled." << endl;
            system("pause");
            StaffControlDelete();
        }
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
        StaffControlDelete();
    }
}

void DeleteBlood(sql::Connection* conn)
{
    string StockID;
    char confirmDel, continueDel;
    system("cls");

    cout << "-----------------------------" << endl;
    cout << " DELETE RECORD - BLOOD STOCK " << endl;
    cout << "-----------------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::Statement* stmt = conn->createStatement();
        sql::ResultSet* resAll = stmt->executeQuery(
            "SELECT StockID, BloodType, Quantity, DateReceived, ExpiryDate, Status, DonationID FROM BloodStock"
        );

        cout << "\n================ ALL BLOOD STOCK ================\n\n";

        cout << left
            << setw(12) << "StockID"
            << setw(12) << "Type"
            << setw(10) << "Qty"
            << setw(15) << "Received"
            << setw(15) << "Expiry"
            << setw(15) << "Status"
            << setw(15) << "DonationID"
            << endl;

        cout << "--------------------------------------------------------------------------\n";

        while (resAll->next()) {
            cout << left
                << setw(12) << resAll->getString("StockID")
                << setw(12) << resAll->getString("BloodType")
                << setw(10) << resAll->getInt("Quantity")
                << setw(15) << resAll->getString("DateReceived")
                << setw(15) << resAll->getString("ExpiryDate")
                << setw(15) << resAll->getString("Status")
                << setw(15) << resAll->getString("DonationID")
                << endl;
        }

        delete resAll;
        delete stmt;

        cout << "\nEnter Blood Stock ID to delete: ";
        cin >> StockID;

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT StockID, BloodType, Quantity, DateReceived, ExpiryDate, Status, DonationID "
            "FROM BloodStock WHERE StockID = ?"
        );
        pstmt->setString(1, StockID);
        sql::ResultSet* res = pstmt->executeQuery();

        if (!res->next()) {
            cout << "\nNo blood stock found with ID " << StockID << endl;
            delete res;
            delete pstmt;
            system("pause");
            StaffControlDelete();
            return;
        }

        cout << "\nHere's the record found:\n" << endl;
        cout << "Stock ID     : " << res->getString("StockID") << endl;
        cout << "Blood Type   : " << res->getString("BloodType") << endl;
        cout << "Quantity     : " << res->getInt("Quantity") << endl;
        cout << "Date Received: " << res->getString("DateReceived") << endl;
        cout << "Expiry Date  : " << res->getString("ExpiryDate") << endl;
        cout << "Status       : " << res->getString("Status") << endl;
        cout << "Donation ID  : " << res->getString("DonationID") << endl;

        delete res;
        delete pstmt;

        cout << "\nAre you sure to delete this record [Y/N]: ";
        cin >> confirmDel;

        if (confirmDel == 'Y' || confirmDel == 'y')
        {
            sql::PreparedStatement* delStmt = conn->prepareStatement(
                "DELETE FROM BloodStock WHERE StockID = ?"
            );
            delStmt->setString(1, StockID);
            delStmt->executeUpdate();

            cout << "\nSuccessfully deleted the blood stock!" << endl;

            delete delStmt;

            cout << "\nDo you want to continue deleting record? [Y/N]: ";
            cin >> continueDel;

            if (continueDel == 'Y' || continueDel == 'y')
                DeleteBlood(conn);
            else
                StaffControlDelete();
        }
        else
        {
            cout << "\nDeletion cancelled." << endl;
            system("pause");
            StaffControlDelete();
        }
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
        StaffControlDelete();
    }
}

void DeleteDonation(sql::Connection* conn)
{
    string DonationID;
    char confirmDel, continueDel;
    system("cls");

    cout << "--------------------------" << endl;
    cout << " DELETE RECORD - DONATION " << endl;
    cout << "--------------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::Statement* stmt = conn->createStatement();
        sql::ResultSet* resAll = stmt->executeQuery(
            "SELECT DonationID, DonationDate, BloodVolume, BloodType, DonorID, StaffID FROM Donation"
        );

        cout << "\n================ ALL DONATIONS ================\n\n";
        cout << left
            << setw(12) << "DonationID"
            << setw(15) << "Date"
            << setw(12) << "Volume"
            << setw(10) << "Type"
            << setw(12) << "DonorID"
            << setw(12) << "StaffID"
            << endl;
        cout << "---------------------------------------------------------------\n";

        while (resAll->next()) {
            cout << left
                << setw(12) << resAll->getString("DonationID")
                << setw(15) << resAll->getString("DonationDate")
                << setw(12) << resAll->getDouble("BloodVolume")
                << setw(10) << resAll->getString("BloodType")
                << setw(12) << resAll->getString("DonorID")
                << setw(12) << resAll->getString("StaffID")
                << endl;
        }

        delete resAll;
        delete stmt;

        cout << "\nEnter Donation ID to delete: ";
        cin >> DonationID;

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT DonationID, DonationDate, BloodVolume, BloodType, DonorID, StaffID "
            "FROM Donation WHERE DonationID = ?"
        );
        pstmt->setString(1, DonationID);
        sql::ResultSet* res = pstmt->executeQuery();

        if (!res->next()) {
            cout << "No donation found with ID " << DonationID << endl;
            delete res;
            delete pstmt;
            system("pause");
            StaffControlDelete();
            return;
        }

        cout << "\nHere's the record found: \n" << endl;
        cout << "Donation ID   : " << res->getString("DonationID") << endl;
        cout << "Donation Date : " << res->getString("DonationDate") << endl;
        cout << "Blood Volume  : " << res->getDouble("BloodVolume") << endl;
        cout << "Blood Type    : " << res->getString("BloodType") << endl;
        cout << "Donor ID      : " << res->getString("DonorID") << endl;
        cout << "Staff ID      : " << res->getString("StaffID") << endl;

        delete res;
        delete pstmt;

        cout << "\nAre you sure to delete this record [Y/N]: ";
        cin >> confirmDel;

        if (confirmDel == 'Y' || confirmDel == 'y')
        {
            // Get DonorID of the donation to be deleted
            string donorID;
            sql::PreparedStatement* pstmtCheck = conn->prepareStatement(
                "SELECT DonorID FROM Donation WHERE DonationID = ?"
            );
            pstmtCheck->setString(1, DonationID);
            sql::ResultSet* resCheck = pstmtCheck->executeQuery();
            if (resCheck->next())
                donorID = resCheck->getString("DonorID");
            delete resCheck;
            delete pstmtCheck;

            sql::PreparedStatement* delStmt = conn->prepareStatement(
                "DELETE FROM Donation WHERE DonationID = ?"
            );
            delStmt->setString(1, DonationID);
            delStmt->executeUpdate();
            cout << "\nSuccessfully deleted the donation!" << endl;
            delete delStmt;

            // ===== Update LastDonationDate for the donor =====
            sql::PreparedStatement* updateLastDate = conn->prepareStatement(
                "UPDATE Donor SET LastDonationDate = "
                "(SELECT MAX(DonationDate) FROM Donation WHERE DonorID = ?) "
                "WHERE DonorID = ?"
            );
            updateLastDate->setString(1, donorID);
            updateLastDate->setString(2, donorID);
            updateLastDate->executeUpdate();
            delete updateLastDate;

            // ===== Update Reward Points after deletion =====
            sql::PreparedStatement* updatePoints = conn->prepareStatement(
                "UPDATE RewardPoints SET TotalPoints = TotalPoints - 10 WHERE DonorID = ?"
            );
            updatePoints->setString(1, donorID);
            updatePoints->executeUpdate();
            delete updatePoints;

            // ===== Update Reward Level automatically =====
            sql::PreparedStatement* updateLevel = conn->prepareStatement(
                "UPDATE RewardPoints SET RewardLevel = CASE "
                "WHEN TotalPoints >= 200 THEN 'Gold' "
                "WHEN TotalPoints >= 100 THEN 'Silver' "
                "WHEN TotalPoints >= 0 THEN 'Bronze' "
                "END WHERE DonorID = ?"
            );
            updateLevel->setString(1, donorID);
            updateLevel->executeUpdate();
            delete updateLevel;

            cout << "\nDo you want to continue deleting record? [Y/N]: ";
            cin >> continueDel;
            if (continueDel == 'Y' || continueDel == 'y')
                DeleteDonation(conn);
            else
                StaffControlDelete();
        }
        else
        {
            cout << "\nDeletion cancelled." << endl;
            system("pause");
            StaffControlDelete();
        }
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
        StaffControlDelete();
    }
}

void StaffControlUpdate()
{
    int StaffUpdate;
    system("cls");
    do
    {
        cout << "--------------------" << endl;
        cout << " UPDATE RECORD MENU " << endl;
        cout << "--------------------" << endl;

        cout << "[1] Update Record of Donors" << endl;
        cout << "[2] Update Record of Blood Stock" << endl;
        cout << "[3] Update Record of Donation" << endl;
        cout << "[4] Main Menu" << endl;

        cout << "\nPlease enter your choice: ";
        cin >> StaffUpdate;

        switch (StaffUpdate) {
        case 1:
            UpdateDonor(conn);
            break;

        case 2:
            UpdateBlood(conn);
            break;

        case 3:
            UpdateDonation(conn);
            break;

        case 4:
            StaffControlMain();
            break;

        default:
            cout << "Invalid choice!" << endl;
            system("pause");
            break;
        }
        system("cls");
    } while (StaffUpdate != 4);
    StaffControlUpdate();
}

void UpdateDonor(sql::Connection* conn)
{
    string DonorID, DonorName, DonorGender, DonorDOB, DonorAddress, DonorBloodType, DonorPhone, DonorPassword, DonorEmail;
    double DonorHeight, DonorWeight;
    int DonorAge;

    char UpdChoice, confirmUpd, continueUpd;
    system("cls");

    cout << "-----------------------" << endl;
    cout << " UPDATE RECORD - DONOR " << endl;
    cout << "-----------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* connList = driver->connect(server, username, password);
        connList->setSchema("bloodbankmanagementdb");

        sql::Statement* stmt = connList->createStatement();
        sql::ResultSet* listRes = stmt->executeQuery(
            "SELECT DonorID, DonorName, DonorGender, DonorAge, DonorPhone, DonorEmail, DonorAddress, DonorBloodType, DonorHeight, DonorWeight FROM donor"
        );

        cout << "\n===================================================== DONOR LIST =====================================================\n";
        cout << left
            << setw(7) << "ID"
            << setw(15) << "NAME"
            << setw(10) << "GENDER"
            << setw(5) << "AGE"
            << setw(13) << "PHONE"
            << setw(23) << "EMAIL"
            << setw(37) << "ADDRESS"
            << setw(8) << "BLOOD"
            << setw(8) << "HEIGHT"
            << setw(8) << "WEIGHT" << endl;


        cout << "------------------------------------------------------------------------------------------------------------------------------------\n";

        while (listRes->next())
        {
            cout << left
                << setw(7) << listRes->getString("DonorID")
                << setw(15) << listRes->getString("DonorName")
                << setw(10) << listRes->getString("DonorGender")
                << setw(5) << listRes->getInt("DonorAge")
                << setw(13) << listRes->getString("DonorPhone")
                << setw(23) << listRes->getString("DonorEmail")
                << setw(37) << listRes->getString("DonorAddress")
                << setw(8) << listRes->getString("DonorBloodType")
                << setw(8) << listRes->getDouble("DonorHeight")
                << setw(8) << listRes->getDouble("DonorWeight")
                << endl;
        }

        cout << "=======================================================================================================================\n";

        delete listRes;
        delete stmt;
        delete connList;
    }
    catch (...) {
    }

    cout << "\nEnter Donor ID to update (Format: D***): ";
    cin >> DonorID;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT DonorID, DonorName, DonorGender, DonorDOB, DonorAge, DonorAddress, "
            "DonorBloodType, DonorHeight, DonorWeight, DonorPhone, DonorEmail "
            "FROM Donor WHERE DonorID = ?"
        );
        pstmt->setString(1, DonorID);
        sql::ResultSet* res = pstmt->executeQuery();

        if (!res->next()) {
            cout << "\nNo donor found.\n";
            delete res;
            delete pstmt;
            system("pause");
            return;
        }

        // Display record
        cout << "\nRecord Found:\n";
        cout << "Donor ID: " << res->getString("DonorID") << endl;
        cout << "Name: " << res->getString("DonorName") << endl;
        cout << "Gender: " << res->getString("DonorGender") << endl;
        cout << "Age: " << res->getInt("DonorAge") << endl;
        cout << "DOB: " << res->getString("DonorDOB") << endl;
        cout << "Address: " << res->getString("DonorAddress") << endl;
        cout << "Blood Type: " << res->getString("DonorBloodType") << endl;
        cout << "Height: " << res->getDouble("DonorHeight") << endl;
        cout << "Weight: " << res->getDouble("DonorWeight") << endl;
        cout << "Phone: " << res->getString("DonorPhone") << endl;
        cout << "Email: " << res->getString("DonorEmail") << endl;

        delete res;
        delete pstmt;

        cout << "\nUpdate this donor? [Y/N]: ";
        cin >> confirmUpd;

        if (confirmUpd != 'Y' && confirmUpd != 'y') {
            cout << "Update cancelled.\n";
            system("pause");
            StaffControlUpdate();
            return;
        }

        cout << "\nWhich field do you want to update?\n";
        cout << "[1] Name\n";
        cout << "[2] Gender\n";
        cout << "[3] Date of Birth\n";
        cout << "[4] Address\n";
        cout << "[5] Blood Type\n";
        cout << "[6] Height\n";
        cout << "[7] Weight\n";
        cout << "[8] Phone\n";
        cout << "[9] Email\n";
        cout << "[10] Password\n";
        cout << "Your choice >> ";
        cin >> UpdChoice;

        // 1. Name
        if (UpdChoice == '1') {
            cout << "New Name: ";
            cin.ignore();
            getline(cin, DonorName);

            pstmt = conn->prepareStatement("UPDATE Donor SET DonorName=? WHERE DonorID=?");
            pstmt->setString(1, DonorName);
            pstmt->setString(2, DonorID);
            pstmt->executeUpdate();
        }

        // 2. Gender
        else if (UpdChoice == '2') {
            cout << "New Gender (Male/Female): ";
            cin >> DonorGender;

            pstmt = conn->prepareStatement("UPDATE Donor SET DonorGender=? WHERE DonorID=?");
            pstmt->setString(1, DonorGender);
            pstmt->setString(2, DonorID);
            pstmt->executeUpdate();
        }

        // 3. DOB + Age
        else if (UpdChoice == '3') {
            int y, m, d;
            cout << "Enter DOB (YYYY MM DD): ";
            cin >> y >> m >> d;

            DonorDOB = to_string(y) + "-" + to_string(m) + "-" + to_string(d);
            DonorAge = calculateAge(y, m, d);

            pstmt = conn->prepareStatement(
                "UPDATE Donor SET DonorDOB=?, DonorAge=? WHERE DonorID=?"
            );
            pstmt->setString(1, DonorDOB);
            pstmt->setInt(2, DonorAge);
            pstmt->setString(3, DonorID);
            pstmt->executeUpdate();
        }

        // 4. Address
        else if (UpdChoice == '4') {
            cout << "New Address: ";
            cin.ignore();
            getline(cin, DonorAddress);

            pstmt = conn->prepareStatement("UPDATE Donor SET DonorAddress=? WHERE DonorID=?");
            pstmt->setString(1, DonorAddress);
            pstmt->setString(2, DonorID);
            pstmt->executeUpdate();
        }

        // 5. Blood Type
        else if (UpdChoice == '5') {
            cout << "New Blood Type (A/B/AB/O): ";
            cin >> DonorBloodType;

            pstmt = conn->prepareStatement("UPDATE Donor SET DonorBloodType=? WHERE DonorID=?");
            pstmt->setString(1, DonorBloodType);
            pstmt->setString(2, DonorID);
            pstmt->executeUpdate();
        }

        // 6. Height
        else if (UpdChoice == '6') {
            cout << "New Height: ";
            cin >> DonorHeight;

            pstmt = conn->prepareStatement("UPDATE Donor SET DonorHeight=? WHERE DonorID=?");
            pstmt->setDouble(1, DonorHeight);
            pstmt->setString(2, DonorID);
            pstmt->executeUpdate();
        }

        // 7. Weight
        else if (UpdChoice == '7') {
            cout << "New Weight: ";
            cin >> DonorWeight;

            pstmt = conn->prepareStatement("UPDATE Donor SET DonorWeight=? WHERE DonorID=?");
            pstmt->setDouble(1, DonorWeight);
            pstmt->setString(2, DonorID);
            pstmt->executeUpdate();
        }

        // 8. Phone
        else if (UpdChoice == '8') {
            cout << "New Phone: ";
            cin >> DonorPhone;

            pstmt = conn->prepareStatement("UPDATE Donor SET DonorPhone=? WHERE DonorID=?");
            pstmt->setString(1, DonorPhone);
            pstmt->setString(2, DonorID);
            pstmt->executeUpdate();
        }

        // 9. Email
        else if (UpdChoice == '9') {
            cout << "New Email: ";
            cin >> DonorEmail;

            pstmt = conn->prepareStatement("UPDATE Donor SET DonorEmail=? WHERE DonorID=?");
            pstmt->setString(1, DonorEmail);
            pstmt->setString(2, DonorID);
            pstmt->executeUpdate();
        }

        // 10. Password
        else if (UpdChoice == '10') {
            cout << "New Password: ";
            char ch;
            while ((ch = _getch()) != 13) {
                DonorPassword += ch;
                cout << "*";
            }

            pstmt = conn->prepareStatement(
                "UPDATE Donor SET DonorPassword=? WHERE DonorID=?"
            );
            pstmt->setString(1, DonorPassword);
            pstmt->setString(2, DonorID);
            pstmt->executeUpdate();
        }

        delete pstmt;

        cout << "\nSuccessfully Updated!\n";

        cout << "Continue updating another field? [Y/N]: ";
        cin >> continueUpd;

        if (continueUpd == 'Y' || continueUpd == 'y')
            UpdateDonor(conn);
        else
            StaffControlUpdate();

    }
    catch (sql::SQLException& e) {
        cout << "\nSQL Error: " << e.what() << endl;
        system("pause");
    }
}

void UpdateBlood(sql::Connection* conn)
{
    string StockID, BloodType, Status, ExpiryDate;
    int Quantity;
    char UpdChoice, confirmUpd, continueUpd;

    system("cls");
    cout << "-----------------------------" << endl;
    cout << " UPDATE RECORD - BLOOD STOCK " << endl;
    cout << "-----------------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        cout << "\n================================ BLOOD STOCK LIST ================================\n";

        sql::Statement* stmt = conn->createStatement();
        sql::ResultSet* listRes = stmt->executeQuery(
            "SELECT StockID, BloodType, Quantity, DateReceived, ExpiryDate, Status, DonationID "
            "FROM BloodStock"
        );

        cout << left
            << setw(12) << "StockID"
            << setw(12) << "Type"
            << setw(10) << "Qty"
            << setw(15) << "Received"
            << setw(15) << "Expiry"
            << setw(15) << "Status"
            << setw(15) << "DonationID"
            << endl;

        cout << "------------------------------------------------------------------------------------\n";

        while (listRes->next()) {
            cout << left
                << setw(12) << listRes->getString("StockID")
                << setw(12) << listRes->getString("BloodType")
                << setw(10) << listRes->getInt("Quantity")
                << setw(15) << listRes->getString("DateReceived")
                << setw(15) << listRes->getString("ExpiryDate")
                << setw(15) << listRes->getString("Status")
                << setw(15) << listRes->getString("DonationID")
                << endl;
        }

        cout << "==================================================================================\n\n";

        delete listRes;
        delete stmt;

        cout << "Enter Blood Stock ID to search (Format: BS***): ";
        cin >> StockID;

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT * FROM BloodStock WHERE StockID = ?"
        );
        pstmt->setString(1, StockID);
        sql::ResultSet* res = pstmt->executeQuery();

        if (!res->next()) {
            cout << "No blood stock found with ID " << StockID << endl;
            delete res;
            delete pstmt;
            system("pause");
            StaffControlUpdate();
            return;
        }

        // Display found record
        cout << "\nHere's the record found:\n\n";
        cout << "Stock ID: " << res->getString("StockID") << endl;
        cout << "Blood Type: " << res->getString("BloodType") << endl;
        cout << "Quantity: " << res->getInt("Quantity") << endl;
        cout << "Date Received: " << res->getString("DateReceived") << endl;
        cout << "Expiry Date: " << res->getString("ExpiryDate") << endl;
        cout << "Status: " << res->getString("Status") << endl;
        cout << "Donation ID: " << res->getString("DonationID") << endl;

        delete res;
        delete pstmt;

        cout << "\nAre you sure to update this record? [Y/N]: ";
        cin >> confirmUpd;
        if (!(confirmUpd == 'Y' || confirmUpd == 'y')) {
            cout << "Update cancelled.\n";
            system("pause");
            StaffControlUpdate();
            return;
        }

        // Update menu
        cout << "\nSelect information to update:\n";
        cout << "[1] Blood Type\n";
        cout << "[2] Quantity\n";
        cout << "[3] Expiry Date\n";
        cout << "[4] Status\n";
        cout << "\nYour choice >> ";
        cin >> UpdChoice;

        sql::PreparedStatement* updateStmt = nullptr;

        switch (UpdChoice) {
        case '1':
            cout << "New Blood Type (A/B/AB/O): ";
            cin >> BloodType;
            updateStmt = conn->prepareStatement("UPDATE BloodStock SET BloodType = ? WHERE StockID = ?");
            updateStmt->setString(1, BloodType);
            updateStmt->setString(2, StockID);
            break;

        case '2':
            cout << "New Quantity: ";
            cin >> Quantity;
            updateStmt = conn->prepareStatement("UPDATE BloodStock SET Quantity = ? WHERE StockID = ?");
            updateStmt->setInt(1, Quantity);
            updateStmt->setString(2, StockID);
            break;

        case '3':
            cout << "New Expiry Date (YYYY-MM-DD): ";
            cin >> ExpiryDate;
            updateStmt = conn->prepareStatement("UPDATE BloodStock SET ExpiryDate = ? WHERE StockID = ?");
            updateStmt->setString(1, ExpiryDate);
            updateStmt->setString(2, StockID);
            break;

        case '4':
            cout << "New Status (Available/Unavailable): ";
            cin >> Status;
            updateStmt = conn->prepareStatement("UPDATE BloodStock SET Status = ? WHERE StockID = ?");
            updateStmt->setString(1, Status);
            updateStmt->setString(2, StockID);
            break;

        default:
            cout << "Invalid choice!\n";
            system("pause");
            UpdateBlood(conn);
            return;
        }

        updateStmt->executeUpdate();
        delete updateStmt;

        cout << "\nSuccessfully updated!\n";

        cout << "Do you want to continue updating records? [Y/N]: ";
        cin >> continueUpd;

        if (continueUpd == 'Y' || continueUpd == 'y')
            UpdateBlood(conn);
        else
            StaffControlUpdate();

    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
        StaffControlUpdate();
    }
}

void UpdateDonation(sql::Connection* conn)
{
    string DonationID, DonorID, StaffID, BloodType;
    double BloodVolume;
    char UpdChoice, confirmUpd, continueUpd;

    system("cls");
    cout << "--------------------------" << endl;
    cout << " UPDATE RECORD - DONATION " << endl;
    cout << "--------------------------" << endl;

    try
    {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::Statement* stmt = conn->createStatement();
        sql::ResultSet* listRes = stmt->executeQuery(
            "SELECT DonationID, DonationDate, BloodVolume, BloodType, DonorID, StaffID FROM Donation"
        );

        cout << "\n============================== DONATION LIST ==============================\n";
        cout << left
            << setw(12) << "DonationID"
            << setw(15) << "Date"
            << setw(12) << "Volume"
            << setw(12) << "Type"
            << setw(12) << "DonorID"
            << setw(12) << "StaffID"
            << endl;

        cout << "----------------------------------------------------------------------------\n";

        while (listRes->next())
        {
            cout << left
                << setw(12) << listRes->getString("DonationID")
                << setw(15) << listRes->getString("DonationDate")
                << setw(12) << listRes->getDouble("BloodVolume")
                << setw(12) << listRes->getString("BloodType")
                << setw(12) << listRes->getString("DonorID")
                << setw(12) << listRes->getString("StaffID")
                << endl;
        }

        cout << "=============================================================================\n\n";

        delete listRes;
        delete stmt;

        cout << "Enter Donation ID to search (Format: DN***): ";
        cin >> DonationID;

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT DonationID, DonationDate, BloodVolume, BloodType, DonorID, StaffID "
            "FROM Donation WHERE DonationID = ?"
        );
        pstmt->setString(1, DonationID);
        sql::ResultSet* res = pstmt->executeQuery();

        if (!res->next())
        {
            cout << "No donation found with ID " << DonationID << endl;
            delete res;
            delete pstmt;
            system("pause");
            return;
        }

        cout << "Donation ID: " << res->getString("DonationID") << endl;
        cout << "Donation Date: " << res->getString("DonationDate") << endl;
        cout << "Blood Volume: " << res->getDouble("BloodVolume") << endl;
        cout << "Blood Type: " << res->getString("BloodType") << endl;
        cout << "Donor ID: " << res->getString("DonorID") << endl;
        cout << "Staff ID: " << res->getString("StaffID") << endl;

        BloodVolume = res->getDouble("BloodVolume");
        BloodType = res->getString("BloodType");
        DonorID = res->getString("DonorID");
        StaffID = res->getString("StaffID");

        delete res;
        delete pstmt;

        cout << "\nDo you want to update this record? [Y/N]: ";
        cin >> confirmUpd;
        if (!(confirmUpd == 'Y' || confirmUpd == 'y')) {
            cout << "Update cancelled." << endl;
            system("pause");
            StaffControlUpdate();
            return;
        }

        cout << "----------------------------" << endl;
        cout << "  Updation of Information " << endl;
        cout << "----------------------------" << endl;
        cout << "[1] Blood Volume\n[2] Blood Type\n[3] Donor ID\n[4] Staff ID\nYour choice >> ";
        cin >> UpdChoice;

        sql::PreparedStatement* updStmt = nullptr;

        if (UpdChoice == '1')
        {
            cout << "New Blood Volume: ";
            cin >> BloodVolume;
            updStmt = conn->prepareStatement(
                "UPDATE Donation SET BloodVolume = ? WHERE DonationID = ?"
            );
            updStmt->setDouble(1, BloodVolume);
            updStmt->setString(2, DonationID);
        }
        else if (UpdChoice == '2')
        {
            cout << "New Blood Type: ";
            cin >> BloodType;
            updStmt = conn->prepareStatement(
                "UPDATE Donation SET BloodType = ? WHERE DonationID = ?"
            );
            updStmt->setString(1, BloodType);
            updStmt->setString(2, DonationID);
        }
        else if (UpdChoice == '3')
        {
            cout << "New Donor ID: ";
            cin >> DonorID;
            updStmt = conn->prepareStatement(
                "UPDATE Donation SET DonorID = ? WHERE DonationID = ?"
            );
            updStmt->setString(1, DonorID);
            updStmt->setString(2, DonationID);
        }
        else if (UpdChoice == '4')
        {
            cout << "New Staff ID: ";
            cin >> StaffID;
            updStmt = conn->prepareStatement(
                "UPDATE Donation SET StaffID = ? WHERE DonationID = ?"
            );
            updStmt->setString(1, StaffID);
            updStmt->setString(2, DonationID);
        }
        else
        {
            cout << "Invalid choice!" << endl;
            return;
        }

        if (updStmt)
        {
            updStmt->executeUpdate();
            delete updStmt;
            cout << "\nSuccessfully updated!" << endl;

            cout << "Do you want to continue updating records? [Y/N]: ";
            cin >> continueUpd;
            if (continueUpd == 'Y' || continueUpd == 'y')
                UpdateDonation(conn);
            else
                StaffControlUpdate();
        }
    }
    catch (sql::SQLException& e)
    {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
    }
}

void StaffControlSearch()
{
    int StaffSearch;
    system("cls");

    cout << "--------------------" << endl;
    cout << " SEARCH RECORD MENU " << endl;
    cout << "--------------------" << endl;

    cout << "[1] Search Record of Donors" << endl;
    cout << "[2] Search Record of Blood Stock" << endl;
    cout << "[3] Search Record of Donation" << endl;
    cout << "[4] Main Menu" << endl;

    cout << "\nPlease enter your choice: ";
    cin >> StaffSearch;

    switch (StaffSearch) {
    case 1:
        SearchDonor(conn);
        break;

    case 2:
        SearchBlood(conn);
        break;

    case 3:
        SearchDonation(conn);
        break;

    case 4:
        StaffControlMain();
        break;

    default:
        cout << "Invalid choice!" << endl;
        system("pause");
        StaffControlSearch();
        break;
    }
}

void SearchDonor(sql::Connection* conn)
{
    string DonorID, DonorName, DonorGender, DonorDOB, DonorAddress, DonorBloodType, DonorPhone, DonorEmail, LastDonationDate;
    int DonorAge;
    double DonorHeight, DonorWeight;
    int searchDonor;
    char SearchDon;

    system("cls");
    cout << "-----------------------" << endl;
    cout << " SEARCH RECORD - DONOR " << endl;
    cout << "-----------------------" << endl;
    cout << "\nPlease select the attribute you want to search: " << endl;
    cout << "[1] Donor ID \n[2] Name \n[3] Gender \n[4] Age \n[5] Date of Birth \n[6] Address \n"
        << "[7] Blood Type \n[8] Height \n[9] Weight \n[10] Phone \n[11] Email \n[12] Last Donation Date \n[13] Back to Main Menu\n";
    cout << "\nYour Choice >> ";
    cin >> searchDonor;

    try
    {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = nullptr;
        sql::ResultSet* res = nullptr;

        switch (searchDonor)
        {
        case 1:
            cout << "Enter Donor ID to search (Format: D***): ";
            cin >> DonorID;
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorID = ?");
            pstmt->setString(1, DonorID);
            break;
        case 2:
            cout << "Enter Donor Name to search: ";
            cin.ignore(1, '\n');
            getline(cin, DonorName);
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorName LIKE ?");
            pstmt->setString(1, "%" + DonorName + "%");
            break;
        case 3:
            cout << "Enter Donor Gender to search [Male/Female]: ";
            cin >> DonorGender;
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorGender = ?");
            pstmt->setString(1, DonorGender);
            break;
        case 4:
            cout << "Enter Donor Age to search: ";
            cin >> DonorAge;
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorAge = ?");
            pstmt->setInt(1, DonorAge);
            break;
        case 5:
            cout << "Enter Date of Birth to search (YYYY-MM-DD): ";
            cin >> DonorDOB;
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorDOB LIKE ?");
            pstmt->setString(1, "%" + DonorDOB + "%");
            break;
        case 6:
            cout << "Enter Address to search: ";
            cin.ignore(1, '\n');
            getline(cin, DonorAddress);
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorAddress LIKE ?");
            pstmt->setString(1, "%" + DonorAddress + "%");
            break;
        case 7:
            cout << "Enter Blood Type to search [A, B, AB, O]: ";
            cin >> DonorBloodType;
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorBloodType = ?");
            pstmt->setString(1, DonorBloodType);
            break;
        case 8:
            cout << "Enter Height to search: ";
            cin >> DonorHeight;
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorHeight = ?");
            pstmt->setDouble(1, DonorHeight);
            break;
        case 9:
            cout << "Enter Weight to search: ";
            cin >> DonorWeight;
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorWeight = ?");
            pstmt->setDouble(1, DonorWeight);
            break;
        case 10:
            cout << "Enter Phone Number to search: ";
            cin >> DonorPhone;
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorPhone LIKE ?");
            pstmt->setString(1, "%" + DonorPhone + "%");
            break;
        case 11:
            cout << "Enter Email to search: ";
            cin >> DonorEmail;
            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE DonorEmail LIKE ?");
            pstmt->setString(1, "%" + DonorEmail + "%");
            break;
        case 12: 
            cout << "Enter Last Donation Date to search (YYYY-MM-DD): ";
            cin >> LastDonationDate;

            pstmt = conn->prepareStatement(
                "SELECT * FROM donor WHERE LastDonationDate LIKE ?");
            pstmt->setString(1, "%" + LastDonationDate + "%");
            break;
        case 13:
            StaffControlSearch();
            return;
        default:
            cout << "Error! Invalid input for searching!" << endl;
            system("pause");
            StaffControlSearch();
            return;
        }

        res = pstmt->executeQuery();
        bool found = false;

        while (res->next())
        {
            found = true;
            cout << "Donor ID: " << res->getString("DonorID") << endl;
            cout << "Name: " << res->getString("DonorName") << endl;
            cout << "Gender: " << res->getString("DonorGender") << endl;
            cout << "Age: " << res->getInt("DonorAge") << endl;
            cout << "Date of Birth: " << res->getString("DonorDOB") << endl;
            cout << "Address: " << res->getString("DonorAddress") << endl;
            cout << "Blood Type: " << res->getString("DonorBloodType") << endl;
            cout << "Height: " << res->getDouble("DonorHeight") << endl;
            cout << "Weight: " << res->getDouble("DonorWeight") << endl;
            cout << "Phone: " << res->getString("DonorPhone") << endl;
            cout << "Email: " << res->getString("DonorEmail") << endl;
            cout << "Last Donation Date: " << res->getString("LastDonationDate") << endl;
            cout << endl;
        }

        if (!found)
            cout << "No records found!" << endl;

        delete res;
        delete pstmt;

        cout << "Do you want to search another donor? [Y/N]: ";
        cin >> SearchDon;
        if (SearchDon == 'y' || SearchDon == 'Y')
            SearchDonor(conn);
        else
            StaffControlMain();
    }
    catch (sql::SQLException& e)
    {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
        StaffControlSearch();
    }
}

void SearchBlood(sql::Connection* conn)
{
    string StockID, BloodType, DonationID;
    int Quantity;
    string DateReceived, ExpiryDate;
    char SearchMore;
    int choice;

    system("cls");
    cout << "-----------------------------" << endl;
    cout << " SEARCH RECORD - BLOOD STOCK " << endl;
    cout << "-----------------------------" << endl;

    cout << "Select attribute to search: " << endl;
    cout << "[1] Stock ID" << endl;
    cout << "[2] Blood Type" << endl;
    cout << "[3] Quantity" << endl;
    cout << "[4] Date Received" << endl;
    cout << "[5] Expiry Date" << endl;
    cout << "[6] Donation ID" << endl;
    cout << "[7] Back to Main Menu" << endl;

    cout << "Your choice >> ";
    cin >> choice;

    try
    {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt;
        sql::ResultSet* res;

        switch (choice)
        {
        case 1:
            cout << "Enter Stock ID (BS***): ";
            cin >> StockID;
            pstmt = conn->prepareStatement(
                "SELECT * FROM BloodStock WHERE StockID = ?");
            pstmt->setString(1, StockID);
            break;

        case 2:
            cout << "Enter Blood Type (A, B, AB, O): ";
            cin >> BloodType;
            pstmt = conn->prepareStatement(
                "SELECT * FROM BloodStock WHERE BloodType = ?");
            pstmt->setString(1, BloodType);
            break;

        case 3:
            cout << "Enter Quantity: ";
            cin >> Quantity;
            pstmt = conn->prepareStatement(
                "SELECT * FROM BloodStock WHERE Quantity = ?");
            pstmt->setInt(1, Quantity);
            break;

        case 4:
            cout << "Enter Date Received (YYYY-MM-DD): ";
            cin >> DateReceived;
            pstmt = conn->prepareStatement(
                "SELECT * FROM BloodStock WHERE DateReceived = ?");
            pstmt->setString(1, DateReceived);
            break;

        case 5:
            cout << "Enter Expiry Date (YYYY-MM-DD): ";
            cin >> ExpiryDate;
            pstmt = conn->prepareStatement(
                "SELECT * FROM BloodStock WHERE ExpiryDate = ?");
            pstmt->setString(1, ExpiryDate);
            break;

        case 6:
            cout << "Enter Donation ID (DN***): ";
            cin >> DonationID;
            pstmt = conn->prepareStatement(
                "SELECT * FROM BloodStock WHERE DonationID = ?");
            pstmt->setString(1, DonationID);
            break;

        case 7:
            StaffControlSearch();
            return; 

        default:
            cout << "Invalid input!" << endl;
            return;
        }

        res = pstmt->executeQuery();

        bool found = false;
        while (res->next())
        {
            found = true;
            cout << "StockID: " << res->getString("StockID") << endl;
            cout << "BloodType: " << res->getString("BloodType") << endl;
            cout << "Quantity: " << res->getInt("Quantity") << endl;
            cout << "DateReceived: " << res->getString("DateReceived") << endl;
            cout << "ExpiryDate: " << res->getString("ExpiryDate") << endl;
            cout << "Status: " << res->getString("Status") << endl;
            cout << "DonationID: " << res->getString("DonationID") << endl;
            cout << "----------------------------" << endl;
        }

        if (!found)
            cout << "No records found!" << endl;

        cout << "Do you want to search another blood stock? (y/n): ";
        cin >> SearchMore;
        if (SearchMore == 'y' || SearchMore == 'Y')
            SearchBlood(conn);
        else
            StaffControlMain();

        delete res;
        delete pstmt;
    }
    catch (sql::SQLException& e)
    {
        cout << "ERROR: " << e.what() << endl;
    }
}

void SearchDonation(sql::Connection* conn)
{
    system("cls");
    string DonationID, DonationDate, DonorID, StaffID, BloodType;
    double BloodVolume;
    int searchOption;
    char SearchAgain;

    cout << "--------------------------" << endl;
    cout << " SEARCH RECORD - DONATION " << endl;
    cout << "--------------------------" << endl;
    cout << "Please select the attribute you want to search: " << endl;
    cout << "[1] Donation ID" << endl;
    cout << "[2] Donation Date" << endl;
    cout << "[3] Donor ID" << endl;
    cout << "[4] Staff ID" << endl;
    cout << "[5] Blood Type" << endl;
    cout << "[6] Blood Volume" << endl;
    cout << "[7] Back to Main Menu" << endl;

    cout << "\nYour Choice >> ";
    cin >> searchOption;

    string query;

    if (searchOption == 1) {
        cout << "\nEnter Donation ID (Format: DN***): ";
        cin >> DonationID;
        query = "SELECT * FROM Donation WHERE DonationID = '" + DonationID + "'";
    }
    else if (searchOption == 2) {
        cout << "\nEnter Donation Date to search (YYYY-MM-DD or part): ";
        cin >> DonationDate;
        query = "SELECT * FROM Donation WHERE DonationDate LIKE '%" + DonationDate + "%'";
    }
    else if (searchOption == 3) {
        cout << "\nEnter Donor ID (Format: D***): ";
        cin >> DonorID;
        query = "SELECT * FROM Donation WHERE DonorID = '" + DonorID + "'";
    }
    else if (searchOption == 4) {
        cout << "\nEnter Staff ID (Format: S***): ";
        cin >> StaffID;
        query = "SELECT * FROM Donation WHERE StaffID = '" + StaffID + "'";
    }
    else if (searchOption == 5) {
        cout << "\nEnter Blood Type (A, B, AB, O): ";
        cin >> BloodType;
        query = "SELECT * FROM Donation WHERE BloodType = '" + BloodType + "'";
    }
    else if (searchOption == 6) {
        cout << "\nEnter Blood Volume to search: ";
        cin >> BloodVolume;
        query = "SELECT * FROM Donation WHERE BloodVolume = " + to_string(BloodVolume);
    }
    else if (searchOption == 7) {
        StaffControlSearch();
        return;
    }
    else {
        cout << "Invalid input!" << endl;
        system("pause");
        StaffControlSearch();
        return;
    }

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::Statement* stmt = conn->createStatement();
        sql::ResultSet* res = stmt->executeQuery(query);

        bool found = false;
        while (res->next()) {
            found = true;
            cout << "Donation ID: " << res->getString("DonationID") << endl;
            cout << "Donation Date: " << res->getString("DonationDate") << endl;
            cout << "Blood Volume: " << res->getDouble("BloodVolume") << endl;
            cout << "Blood Type: " << res->getString("BloodType") << endl;
            cout << "Donor ID: " << res->getString("DonorID") << endl;
            cout << "Staff ID: " << res->getString("StaffID") << endl;
            cout << endl;
        }

        if (!found)
            cout << "No records found!" << endl;

        delete res;
        delete stmt;

        cout << "Do you want to search other donation records? [Y/N]: ";
        cin >> SearchAgain;
        if (SearchAgain == 'y' || SearchAgain == 'Y')
            SearchDonation(conn);
        else
            StaffControlSearch();

    }
    catch (sql::SQLException& e) {
        cout << "Error executing query: " << e.what() << endl;
        system("pause");
        StaffControlSearch();
    }
}

void RecentDonation(sql::Connection* conn, string StaffName)
{
    system("cls");
    cout << "-------------------------" << endl;
    cout << "  BLOOD DONATION RECORD  " << endl;
    cout << "-------------------------" << endl;
    cout << "\nHere is the blood donation record: " << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT "
            "t.DonationID, "
            "t.DonationDate, "
            "d.DonorID, "
            "d.DonorName, "
            "t.BloodVolume, "
            "d.DonorBloodType, "
            "t.StaffID "
            "FROM Donation t "
            "JOIN Donor d ON t.DonorID = d.DonorID "
            "ORDER BY t.DonationID"
        );

        sql::ResultSet* rs = pstmt->executeQuery();

        cout << "-------------------------------------------------------------------------------------\n";
        printf("| %-10s | %-15s | %-8s | %-30s | %-14s | %-10s | %-8s |\n",
            "DonationID", "Donation Date", "DonorID", "Donor Name",
            "Blood Volume", "BloodType", "StaffID");
        cout << "-------------------------------------------------------------------------------------\n";

        while (rs->next())
        {
            printf("| %-10s | %-15s | %-8s | %-30s | %-14s | %-10s | %-8s |\n",
                rs->getString("DonationID").c_str(),
                rs->getString("DonationDate").c_str(),
                rs->getString("DonorID").c_str(),
                rs->getString("DonorName").c_str(),
                rs->getString("BloodVolume").c_str(),
                rs->getString("DonorBloodType").c_str(),
                rs->getString("StaffID").c_str()
            );
        }

        cout << "-------------------------------------------------------------------------------------\n";

        delete rs;
        delete pstmt;

        system("pause");
        system("cls");
        StaffMainMenu(StaffID, StaffName);
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
        system("cls");
        StaffMainMenu(StaffID, StaffName);
    }
}

void StaffReport(sql::Connection* conn, string StaffID, string StaffName)
{
    system("cls");

    // Get current date and time for console display
    time_t now = time(0);
    tm localTime;
    localtime_s(&localTime, &now);
    char dateTimeStr[100];
    strftime(dateTimeStr, sizeof(dateTimeStr), "%A, %m/%d/%Y %I:%M:%S %p", &localTime);

    cout << "=============================================\n";
    cout << "            BLOOD DONATION REPORT            \n";
    cout << "=============================================\n";
    cout << "Generated on: " << dateTimeStr << "\n";

    // ================================
    // COUNT TOTAL DONORS
    // ================================
    string donorNum = "0";
    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT COUNT(*) FROM Donor"
        );

        sql::ResultSet* rs = pstmt->executeQuery();
        if (rs->next())
            donorNum = rs->getString(1);

        delete rs;
        delete pstmt;
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
        StaffMainMenu(StaffID, StaffName);
        return;
    }

    cout << "\nCurrently, there are " << donorNum << " donors registered in the system.\n";

    // ================================
    // INPUT DATE RANGE
    // ================================
    int startYear, startMonth, startDay;
    int endYear, endMonth, endDay;

    cout << "\n---------- REPORT DATE RANGE ----------\n";
    cout << "Start Year (YYYY): ";
    cin >> startYear;
    cout << "Start Month (MM): ";
    cin >> startMonth;
    cout << "Start Day (DD): ";
    cin >> startDay;
    cout << "\nEnd Year (YYYY): ";
    cin >> endYear;
    cout << "End Month (MM): ";
    cin >> endMonth;
    cout << "End Day (DD): ";
    cin >> endDay;

    // Validate dates
    if (startMonth < 1 || startMonth > 12 || endMonth < 1 || endMonth > 12 || endYear < startYear) {
        cout << "Invalid date input!\n";
        system("pause");
        StaffReport(conn, StaffID, StaffName);
        return;
    }

    string StartDate = to_string(startYear) + "-" + to_string(startMonth) + "-" + to_string(startDay);
    string EndDate = to_string(endYear) + "-" + to_string(endMonth) + "-" + to_string(endDay);

    // ================================
    // QUERY DONATION REPORT
    // ================================
    int total = 0;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT Donation.DonationID, Donor.DonorName, Donation.DonationDate, "
            "Donation.BloodVolume, Donation.BloodType "
            "FROM Donation "
            "JOIN Donor ON Donation.DonorID = Donor.DonorID "
            "WHERE Donation.DonationDate BETWEEN ? AND ? "
            "ORDER BY Donation.DonationID"
        );

        pstmt->setString(1, StartDate);
        pstmt->setString(2, EndDate);

        sql::ResultSet* rs = pstmt->executeQuery();

        cout << "\nResults:\n";
        cout << "-----------------------------------------------------------------------------------------\n";
        printf("| %-10s | %-25s | %-12s | %-12s | %-8s |\n",
            "Record", "Donor Name", "Date", "Volume", "Type");
        cout << "-----------------------------------------------------------------------------------------\n";

        while (rs->next()) {
            // Fetch data
            string record = rs->getString(1);
            string donorName = rs->getString(2);
            string date = rs->getString(3);
            string volume = rs->getString(4);
            string type = rs->getString(5);

            // Truncate donor name if too long for display
            string displayName = donorName;
            if (displayName.length() > 25) displayName = displayName.substr(0, 22) + "...";

            // Print formatted line to console
            printf("| %-10s | %-25s | %-12s | %-12s | %-8s |\n",
                record.c_str(),
                displayName.c_str(),
                date.c_str(),
                volume.c_str(),
                type.c_str());

            total++;
        }

        cout << "-----------------------------------------------------------------------------------------\n";
        delete rs;
        delete pstmt;

        cout << "\nTotal donations found: " << total
            << " between " << StartDate << " and " << EndDate << ".\n";

    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
        StaffMainMenu(StaffID, StaffName);
        return;
    }

    // ================================
    // ASK USER IF THEY WANT TO EXPORT TO TXT
    // ================================
    cout << "\n-----------------------------------------\n";
    cout << "Would you like to export this report to a TXT file? (Y/N): ";

    char exportChoice;
    cin >> exportChoice;

    if (toupper(exportChoice) == 'Y') {
        // Get current date and time for filename and file content
        time_t now2 = time(0);
        tm localTime2;
        localtime_s(&localTime2, &now2);

        // Create timestamp for filename (format: StaffReport_YYYYMMDD_HHMMSS.txt)
        char filenameTime[100];
        strftime(filenameTime, sizeof(filenameTime), "%Y%m%d_%H%M%S", &localTime2);
        string filename = "StaffReport_" + string(filenameTime) + ".txt";

        // Create formatted date/time for file content (format: Friday, 12/12/2025 12:39:11 PM)
        char fileDateTimeStr[100];
        strftime(fileDateTimeStr, sizeof(fileDateTimeStr), "%A, %m/%d/%Y %I:%M:%S %p", &localTime2);

        // Open TXT file with timestamped filename
        ofstream reportFile(filename);
        if (reportFile.is_open()) {

            reportFile << "------------------------------\n";
            reportFile << "REPORT GENERATION FOR STAFF\n";
            reportFile << "------------------------------\n";
            reportFile << "Report generated on: " << fileDateTimeStr << "\n\n";

            reportFile << "Currently, there are " << donorNum << " donors registered in the system.\n\n";

            // Format report date range
            string reportStartDate = to_string(startMonth) + "/" + to_string(startDay) + "/" + to_string(startYear);
            string reportEndDate = to_string(endMonth) + "/" + to_string(endDay) + "/" + to_string(endYear);
            reportFile << "Report Period: " << reportStartDate << " to " << reportEndDate << "\n\n";

            try {
                sql::Driver* driver = get_driver_instance();
                sql::Connection* conn = driver->connect(server, username, password);
                conn->setSchema("bloodbankmanagementdb");

                sql::PreparedStatement* pstmt = conn->prepareStatement(
                    "SELECT Donation.DonationID, Donor.DonorName, Donation.DonationDate, "
                    "Donation.BloodVolume, Donation.BloodType "
                    "FROM Donation "
                    "JOIN Donor ON Donation.DonorID = Donor.DonorID "
                    "WHERE Donation.DonationDate BETWEEN ? AND ? "
                    "ORDER BY Donation.DonationID"
                );

                pstmt->setString(1, StartDate);
                pstmt->setString(2, EndDate);

                sql::ResultSet* rs = pstmt->executeQuery();

                // Write report data header to TXT
                reportFile << "DONATION RECORDS:\n";
                reportFile << "-----------------------------------------------------------------------------------------\n";
                reportFile << "| Record     | Donor Name               | Date         | Volume       | Type     |\n";
                reportFile << "-----------------------------------------------------------------------------------------\n";

                int txtTotal = 0;
                while (rs->next()) {
                    // Fetch data
                    string record = rs->getString(1);
                    string donorName = rs->getString(2);
                    string date = rs->getString(3);
                    string volume = rs->getString(4);
                    string type = rs->getString(5);

                    // Truncate donor name if too long for TXT file
                    string displayName = donorName;
                    if (displayName.length() > 25) displayName = displayName.substr(0, 22) + "...";

                    reportFile << "| "
                        << setw(10) << left << record
                        << " | " << setw(25) << left << displayName
                        << " | " << setw(12) << left << date
                        << " | " << setw(12) << left << volume
                        << " | " << setw(8) << left << type
                        << " |\n";

                    txtTotal++;
                }

                reportFile << "-----------------------------------------------------------------------------------------\n";
                reportFile << "\nTotal donations found: " << txtTotal
                    << " between " << reportStartDate << " and " << reportEndDate << ".\n\n";

                reportFile << "Report generated by Staff ID: " << StaffID << " - " << StaffName << "\n";

                delete rs;
                delete pstmt;

                cout << "\nReport successfully saved to '" << filename << "'!\n";
            }
            catch (sql::SQLException& e) {
                cout << "SQL Error during TXT export: " << e.what() << endl;
            }

            reportFile.close();
        }
        else {
            cout << "\nError: Could not open file for writing!\n";
        }
    }

    system("pause");
    StaffMainMenu(StaffID, StaffName);
}

//staff own account information
void StaffAccount(const string& id, sql::Connection* conn, const string& StaffID, const string& StaffName)
{
    system("cls");
    ShowTime();
    cout << "===================================" << endl;
    cout << "       ACCOUNT INFORMATION         " << endl;
    cout << "===================================" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT StaffID, StaffName, StaffGender, StaffAge, StaffPhone, StaffEmail, StaffPosition, StaffRole "
            "FROM Staff WHERE StaffID = ?"
        );
        pstmt->setString(1, id);

        sql::ResultSet* res = pstmt->executeQuery();

        if (res->next()) {
            cout << "Staff ID      : " << res->getString("StaffID") << endl;
            cout << "Name          : " << res->getString("StaffName") << endl;
            cout << "Gender        : " << res->getString("StaffGender") << endl;
            cout << "Age           : " << res->getString("StaffAge") << endl;
            cout << "Phone         : " << res->getString("StaffPhone") << endl;
            cout << "Email         : " << res->getString("StaffEmail") << endl;
            cout << "Position      : " << res->getString("StaffPosition") << endl;
            cout << "Role          : " << res->getString("StaffRole") << endl;
        }
        else {
            cout << "\nNo staff found with ID: " << id << endl;
        }

        delete res;
        delete pstmt;
    }
    catch (sql::SQLException& e) {
        cout << "\nQuery Execution Problem! Error: " << e.what() << endl;
    }

    system("pause");
    system("cls");
    StaffMainMenu(StaffID, StaffName);
}

void DonorLogin()
{
    system("cls");
    string DonorID, DonorPassword;

    cout << "----------------" << endl;
    cout << " LOGIN AS DONOR " << endl;
    cout << "----------------" << endl;

    cout << "Enter Donor ID: ";
    cin >> DonorID;

    cout << "Enter Password: ";
    char ch;
    while ((ch = _getch()) != 13)    
    {
        DonorPassword += ch;
        cout << "*";
    }

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt = conn->prepareStatement(
            "SELECT DonorID, DonorName "
            "FROM Donor "
            "WHERE DonorID = ? AND DonorPassword = ? "
        );

        pstmt->setString(1, DonorID);
        pstmt->setString(2, DonorPassword);

        sql::ResultSet* res = pstmt->executeQuery();

        if (res->next())
        {
            string DonorName = res->getString("DonorName");

            delete res;
            delete pstmt;

            system("cls");
            DonorMainMenu(DonorID, DonorName);  // login successful
        }
        else
        {
            delete res;
            delete pstmt;

            char c;
            cout << "\nInvalid ID or Password. Try again? (Y/N): ";
            cin >> c;

            if (c == 'y' || c == 'Y')
                DonorLogin();
            else
                MainLogin();
        }

    }
    catch (sql::SQLException& e) {
        cout << "Login Error: " << e.what() << endl;
        system("pause");
        MainLogin();
    }
}

void DonorMainMenu(string id, string name)
{
    char DonorMainChoice;
    system("cls");
    cout << "-----------------" << endl;
    cout << " DONOR MAIN MENU " << endl;
    cout << "-----------------" << endl;
    cout << "Welcome, donor " << name << "!" << endl;
    cout << endl;

    cout << "[1] Self Recent Donation" << endl;
    cout << "[2] Account Information" << endl;
    cout << "[3] View Reward Points" << endl;
    cout << "[4] Back to main menu" << endl;

    cout << "Please enter your choice (1 - 4): ";
    cin >> DonorMainChoice;

    switch (DonorMainChoice)
    {
    case '1':
        system("cls");
        DonorDonation(id);

    case '2':
        system("cls");
        DonorAccount(id);
        break;

    case '3':
        RewardPoints(id); 
        break;

    case '4':
        system("CLS");
        main();

    default:
        cout << "Error! Invalid input! " << endl;
        system("pause");
        system("cls");
        DonorMainMenu(id, name);

    }
}

void DonorDonation(string id)
{
    system("cls");

    cout << "--------------------------" << endl;
    cout << "  RECENT DONATION RECORD  " << endl;
    cout << "--------------------------" << endl;
    cout << "\n";

    try {
        // ---------------------------------------------------
        // 1. DISPLAY DONOR BASIC INFO (DonorID, DonorName)
        // ---------------------------------------------------
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* ps1 = conn->prepareStatement(
            "SELECT DonorID, DonorName, LastDonationDate "
            "FROM Donor WHERE DonorID = ?"
        );
        ps1->setString(1, id);
        sql::ResultSet* rs1 = ps1->executeQuery();

        if (rs1->next()) {
            cout << "Donor ID: " << rs1->getString("DonorID") << endl;
            cout << "Name: " << rs1->getString("DonorName") << endl;
            cout << "Last Donation Date: "
                << (rs1->isNull("LastDonationDate") ? "N/A"
                    : rs1->getString("LastDonationDate")) << endl;
        }
        cout << "\n";

        delete rs1;
        delete ps1;

        sql::PreparedStatement* ps2 = conn->prepareStatement(
            "SELECT DonationID, DonationDate, BloodVolume, BloodType, StaffID "
            "FROM Donation WHERE DonorID = ? ORDER BY DonationDate DESC"
        );
        ps2->setString(1, id);
        sql::ResultSet* rs2 = ps2->executeQuery();

        cout << "---------------------------------------------------------------------------------------" << endl;
        printf("| %-10s | %-15s | %-10s | %-8s | %-10s |\n",
            "DonateID", "Date", "Volume", "Type", "StaffID");
        cout << "---------------------------------------------------------------------------------------";

        while (rs2->next()) {
            cout << endl;
            printf("| %-10s | %-15s | %-10s | %-8s | %-10s |\n",
                rs2->getString("DonationID").c_str(),
                rs2->getString("DonationDate").c_str(),
                rs2->getString("BloodVolume").c_str(),
                rs2->getString("BloodType").c_str(),
                rs2->getString("StaffID").c_str()
            );
        }

        cout << "---------------------------------------------------------------------------------------\n";

        delete rs2;
        delete ps2;

        system("pause");
        system("cls");
        DonorMainMenu(id, DonorName);
    }
    catch (sql::SQLException& e) {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
        DonorMainMenu(id, DonorName);
    }
}

void DonorAccount(const string& id)
{
    system("cls");
    ShowTime();

    cout << "===================================" << endl;
    cout << "       ACCOUNT INFORMATION         " << endl;
    cout << "===================================" << endl;

    try
    {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        string query =
            "SELECT DonorID, DonorName, DonorGender, "
            "DonorDOB, DonorAddress, DonorBloodType, "
            "DonorHeight, DonorWeight, DonorPhone, "
            "TIMESTAMPDIFF(YEAR, DonorDOB, CURDATE()) AS Age "
            "FROM Donor WHERE DonorID = ?";

        std::unique_ptr<sql::PreparedStatement> pstmt(conn->prepareStatement(query));
        pstmt->setString(1, id);

        std::unique_ptr<sql::ResultSet> res(pstmt->executeQuery());

        if (res->next())
        {
            cout << "Donor ID: " << res->getString("DonorID") << endl;
            cout << "Name: " << res->getString("DonorName") << endl;
            cout << "Gender: " << res->getString("DonorGender") << endl;
            cout << "Age: " << res->getInt("Age") << endl;
            cout << "Date of Birth: " << res->getString("DonorDOB") << endl;
            cout << "Address: " << res->getString("DonorAddress") << endl;
            cout << "Blood Type: " << res->getString("DonorBloodType") << endl;
            cout << "Height: " << res->getString("DonorHeight") << endl;
            cout << "Weight: " << res->getString("DonorWeight") << endl;
            cout << "Phone: " << res->getString("DonorPhone") << endl;
        }
        else
        {
            cout << "Donor not found!" << endl;
        }

        system("pause");
        system("cls");
        DonorMainMenu(id, DonorName);
    }
    catch (sql::SQLException& e)
    {
        cout << "SQL Error: " << e.what() << endl;
        system("pause");
        system("cls");
        DonorMainMenu(id, DonorName);
    }
}

void RewardPoints(const string& donorID)
{
    system("cls");
    cout << "-------------------------" << endl;
    cout << "   YOUR REWARD POINTS    " << endl;
    cout << "-------------------------" << endl;

    try {
        sql::Driver* driver = get_driver_instance();
        sql::Connection* conn = driver->connect(server, username, password);
        conn->setSchema("bloodbankmanagementdb");

        sql::PreparedStatement* pstmt;
        sql::ResultSet* res;

        // Prepare statement to prevent SQL injection
        pstmt = conn->prepareStatement(
            "SELECT TotalPoints, RewardLevel FROM RewardPoints WHERE DonorID = ?"
        );
        pstmt->setString(1, donorID);

        res = pstmt->executeQuery();

        if (res->next()) {
            cout << "Total Points : " << res->getInt("TotalPoints") << endl;
            cout << "Reward Level : " << res->getString("RewardLevel") << endl;
        }
        else {
            cout << "No reward points found for your account." << endl;
        }

        delete res;
        delete pstmt;
    }
    catch (sql::SQLException& e) {
        cout << "Error fetching reward points: " << e.what() << endl;
    }

    cout << "\nPress any key to return to main menu...";
    _getch();
    DonorMainMenu(DonorID, DonorName); 
}

void Registration()
{
    int userRole;
    string StaffID, StaffName, StaffGender, StaffPhone, StaffEmail, StaffPosition, StaffPassword, StaffRole;
    int StaffAge;
    system("cls");
    cout << "----------------------" << endl;
    cout << " ACCOUNT REGISTRATION " << endl;
    cout << "----------------------" << endl;
    cout << "Kindly choose your registration role." << endl;
    cout << "[1] As Admin / Staff" << endl;
    cout << "[2] As Donor" << endl;
    cout << "[3] Main Menu" << endl;
    cout << "\nYour choice (1 - 3): ";
    cin >> userRole;

    if (userRole == 1) {

        system("cls");
        cout << "------------------------------" << endl;
        cout << " NEW ADMIN/STAFF REGISTRATION " << endl;
        cout << "------------------------------" << endl;
        cout << "Please fill in the following information: " << endl;
        cout << "Name: ";
        cin.ignore(1, '\n');
        getline(cin, StaffName);
        cout << "Gender: ";
        getline(cin, StaffGender);
        cout << "Age: ";
        cin >> StaffAge;
        cin.ignore();
        cout << "Phone Number: ";
        getline(cin, StaffPhone);
        cout << "Email: ";
        getline(cin, StaffEmail);
        cout << "Position: ";
        getline(cin, StaffPosition);
        cout << "Role: ";
        getline(cin, StaffRole);

        cout << "\n------------------------------------------------------" << endl;
        try {
            sql::Driver* driver = get_driver_instance();
            sql::Connection* conn = driver->connect(server, username, password);
            conn->setSchema("bloodbankmanagementdb");

            sql::PreparedStatement* pstmt = conn->prepareStatement(
                "SELECT StaffID FROM staff ORDER BY StaffID DESC LIMIT 1"
            );
            sql::ResultSet* rs = pstmt->executeQuery();

            int nextID = 1; // default if table is empty

            if (rs->next()) {
                string lastID = rs->getString(1);  
                int num = stoi(lastID.substr(1));   
                nextID = num + 1;                  
            }

            // Build new StaffID
            if (nextID < 10)
                StaffID = "S00" + to_string(nextID);
            else if (nextID < 100)
                StaffID = "S0" + to_string(nextID);
            else
                StaffID = "S" + to_string(nextID);

            delete rs;
            delete pstmt;
            delete conn;
        }
        catch (sql::SQLException& e) {
            cout << "Database Error: " << e.what() << endl;
            system("pause");
            return;
        }

        cout << "New Staff ID: " << StaffID << endl;

        cout << "Please enter your password: ";
        char ch1;
        while ((ch1 = _getch()) != 13) // 13 is the ASCII number for Enter
        {
            StaffPassword += ch1;
            cout << "*";
        }

        string conStaffPw;
        cout << "\nRe-enter Password: ";
        char ch2;
        while ((ch2 = _getch()) != 13) 
        {
            conStaffPw += ch2;
            cout << "*";
        }

        cout << "\n";

        if (conStaffPw == StaffPassword) {
            try {
                // Connect to DB
                sql::Driver* driver = get_driver_instance();
                sql::Connection* conn = driver->connect(server, username, password);
                conn->setSchema("bloodbankmanagementdb");

                // Check if StaffID exists
                sql::PreparedStatement* checkStmt = conn->prepareStatement(
                    "SELECT * FROM staff WHERE StaffID = ?"
                );
                checkStmt->setString(1, StaffID);
                sql::ResultSet* res = checkStmt->executeQuery();

                if (res->next()) {
                    cout << "Staff ID already exists. Press Enter to try again...";
                    _getch();
                    delete res;
                    delete checkStmt;
                    delete conn;
                    Registration(); // restart registration
                    return;
                }

                delete res;
                delete checkStmt;

                // Insert new Staff
                sql::PreparedStatement* insertStmt = conn->prepareStatement(
                    "INSERT INTO staff (StaffID, StaffName, StaffGender, StaffAge, StaffPhone, StaffEmail, StaffPosition, StaffPassword, StaffRole) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );

                insertStmt->setString(1, StaffID);
                insertStmt->setString(2, StaffName);
                insertStmt->setString(3, StaffGender);
                insertStmt->setInt(4, StaffAge);
                insertStmt->setString(5, StaffPhone);
                insertStmt->setString(6, StaffEmail);
                insertStmt->setString(7, StaffPosition);
                insertStmt->setString(8, StaffPassword);
                insertStmt->setString(9, StaffRole);

                insertStmt->executeUpdate();
                cout << "\nYou have been registered. Press Enter to continue...";
                _getch();

                delete insertStmt;
                delete conn;

                main();
            }
            catch (sql::SQLException& e) {
                cout << "SQL Error: " << e.what() << endl;
            }

        }
    }
    else if (userRole == 2)
    {
        string DonorID, DonorName, DonorGender, DonorDOB, DonorAddress, DonorPhone, DonorEmail, DonorBloodType, DonorPassword, LastDonationDate;
        int DonorAge;
        double DonorHeight, DonorWeight;
        system("cls");
        cout << "------------------------" << endl;
        cout << " NEW DONOR REGISTRATION " << endl;
        cout << "------------------------" << endl;
        cout << "Please fill in the following information: " << endl;
        cout << "Name: ";
        cin.ignore(1, '\n');
        getline(cin, DonorName);
        cout << "Gender: ";
        getline(cin, DonorGender);

        int d_year, d_month, d_day;
        string year, month, day, DOB;

        cout << "Date of Birth (YYYY-MM-DD): ";
        cin >> d_year >> d_month >> d_day;

        DonorAge = calculateAge(d_year, d_month, d_day);

        //DOB details: convert int to string
        year = to_string(d_year);
        month = to_string(d_month);
        day = to_string(d_day);

        //DOB details: make multiple string into single string
        DOB.append(year);
        DOB.append("-");
        DOB.append(month);
        DOB.append("-");
        DOB.append(day);

        //store the copied single string into Donor_DOB to insert into database later
        DonorDOB = DOB;

        cout << "Address: ";
        cin.ignore(1, '\n');
        getline(cin, DonorAddress);
        cout << "Phone Number: ";
        getline(cin, DonorPhone);
        cout << "Email: ";
        getline(cin, DonorEmail);
        cout << "Blood Type: ";
        getline(cin, DonorBloodType);
        cout << "Height: ";
        cin >> DonorHeight;
        cout << "Weight: ";
        cin >> DonorWeight;

        cout << "\n------------------------------------------------------" << endl;
        try {
            sql::Driver* driver = get_driver_instance();
            sql::Connection* conn = driver->connect(server, username, password);
            conn->setSchema("bloodbankmanagementdb");

            sql::PreparedStatement* pstmt = conn->prepareStatement(
                "SELECT DonorID FROM donor ORDER BY DonorID DESC LIMIT 1"
            );
            sql::ResultSet* rs = pstmt->executeQuery();

            int nextID = 1; // default if table is empty

            if (rs->next()) {
                string lastID = rs->getString(1);  
                int num = stoi(lastID.substr(1));   
                nextID = num + 1;                   
            }

            // Build new DonorID
            if (nextID < 10)
                DonorID = "D00" + to_string(nextID);
            else if (nextID < 100)
                DonorID = "D0" + to_string(nextID);
            else
                DonorID = "D" + to_string(nextID);

            delete rs;
            delete pstmt;
            delete conn;
        }
        catch (sql::SQLException& e) {
            cout << "Database Error: " << e.what() << endl;
            system("pause");
            return;
        }

        cout << "New Donor ID: " << DonorID << endl;

        cout << "Password: ";
        char ch1;
        while ((ch1 = _getch()) != 13) 
        {
            DonorPassword += ch1;
            cout << "*";
        }

        string conDonorPw;
        cout << "\nRe-enter Password: ";
        char ch2;
        while ((ch2 = _getch()) != 13)
        {
            conDonorPw += ch2;
            cout << "*";
        }

        cout << "\n";

        if (conDonorPw == DonorPassword) {
            if (conDonorPw == DonorPassword) {
                try {
                    // 1. Connect to DB
                    sql::Driver* driver = get_driver_instance();
                    sql::Connection* conn = driver->connect(server, username, password);
                    conn->setSchema("bloodbankmanagementdb");

                    // 2. Check if DonorID exists
                    sql::PreparedStatement* checkStmt = conn->prepareStatement(
                        "SELECT * FROM donor WHERE DonorID = ?"
                    );
                    checkStmt->setString(1, DonorID);
                    sql::ResultSet* res = checkStmt->executeQuery();

                    if (res->next()) {
                        cout << "Donor ID already exists. Press Enter to try again...";
                        _getch();
                        delete res;
                        delete checkStmt;
                        delete conn;
                        Registration();
                        return;
                    }

                    delete res;
                    delete checkStmt;

                    // 3. Insert new donor
                    sql::PreparedStatement* insertStmt = conn->prepareStatement(
                        "INSERT INTO donor (DonorID, DonorName, DonorGender, DonorDOB, DonorAddress, DonorPhone, DonorEmail, DonorBloodType, DonorHeight, DonorWeight, DonorPassword, LastDonationDate, DonorAge) "
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                    );
                    insertStmt->setString(1, DonorID);
                    insertStmt->setString(2, DonorName);
                    insertStmt->setString(3, DonorGender);
                    insertStmt->setString(4, DonorDOB);
                    insertStmt->setString(5, DonorAddress);
                    insertStmt->setString(6, DonorPhone);
                    insertStmt->setString(7, DonorEmail);
                    insertStmt->setString(8, DonorBloodType);
                    insertStmt->setDouble(9, DonorHeight);
                    insertStmt->setDouble(10, DonorWeight);
                    insertStmt->setString(11, DonorPassword);
                    insertStmt->setNull(12, sql::DataType::DATE);
                    insertStmt->setInt(13, DonorAge);

                    insertStmt->executeUpdate();
                    cout << "\nYou have been registered. Press Enter to continue...";
                    _getch();

                    delete insertStmt;
                    delete conn;

                    main();
                }
                catch (sql::SQLException& e) {
                    cout << "SQL Error: " << e.what() << endl;
                }
            }
        }
    }
        else if (userRole == 3)
        {
            system("cls");
            main();
        }
        else
        {
            cout << "Invalid Choice. Please try again. " << endl;
            system("pause");
            Registration();
        }
}

void ForgetPassword()
{
    system("cls");
    cout << "-------------------" << endl;
    cout << " PASSWORD RECOVERY " << endl;
    cout << "-------------------" << endl;

    int recover;
    cout << "\nAre you a ?" << endl;
    cout << "[1] Admin/Staff" << endl;
    cout << "[2] Donor" << endl;
    cout << "[3] Main Menu" << endl;

    cout << "\nYour choice: ";
    cin >> recover;

    if (recover == 1)
    {
        string StaffPassword;
        system("cls");
        cout << "-------------" << endl;
        cout << " ADMIN/STAFF " << endl;
        cout << "-------------" << endl;

        cout << "\nPlease insert your Staff ID: ";
        string staffID;
        cin >> staffID;

        cout << "Please insert your phone number for verification: ";
        string staffPhone;
        cin >> staffPhone;

        try {
            sql::Driver* driver = get_driver_instance();
            sql::Connection* conn = driver->connect(server, username, password);
            conn->setSchema("bloodbankmanagementdb");

            // Check if staff exists
            sql::PreparedStatement* pstmt = conn->prepareStatement(
                "SELECT StaffID FROM Staff WHERE StaffID = ? AND StaffPhone = ?"
            );
            pstmt->setString(1, staffID);
            pstmt->setString(2, staffPhone);
            sql::ResultSet* res = pstmt->executeQuery();

            if (!res->next()) {
                cout << "Sorry, no such ID exists!" << endl;
                delete res; delete pstmt;
                system("pause");
                MainLogin();
                return;
            }

            delete res;
            delete pstmt;

            cout << "Staff found!" << endl;
            cout << "Set your new password: ";

            char ch;
            while ((ch = _getch()) != 13)
            {
                StaffPassword += ch;
                cout << "*";
            }

            // Update password
            pstmt = conn->prepareStatement(
                "UPDATE Staff SET StaffPassword = ? WHERE StaffID = ?"
            );
            pstmt->setString(1, StaffPassword);
            pstmt->setString(2, staffID);
            pstmt->executeUpdate();

            delete pstmt;

            cout << "\nSuccessfully updated!" << endl;
            system("pause");
            MainLogin();
        }
        catch (sql::SQLException& e) {
            cout << "SQL Error: " << e.what() << endl;
            system("pause");
            MainLogin();
        }
    }

    else if (recover == 2)
    {
        string DonorPassword;
        system("cls");
        cout << "-------" << endl;
        cout << " DONOR " << endl;
        cout << "-------" << endl;

        cout << "\nPlease insert your Donor ID: ";
        string donorID;
        cin >> donorID;

        cout << "Please insert your phone number for verification: ";
        string donorPhone;
        cin >> donorPhone;

        try {
            sql::Driver* driver = get_driver_instance();
            sql::Connection* conn = driver->connect(server, username, password);
            conn->setSchema("bloodbankmanagementdb");

            // Check if donor exists
            sql::PreparedStatement* pstmt = conn->prepareStatement(
                "SELECT DonorID FROM Donor WHERE DonorID = ? AND DonorPhone = ?"
            );
            pstmt->setString(1, donorID);
            pstmt->setString(2, donorPhone);
            sql::ResultSet* res = pstmt->executeQuery();

            if (!res->next()) {
                cout << "Sorry, no such donor exists!" << endl;
                delete res; delete pstmt;
                system("pause");
                MainLogin();
                return;
            }

            delete res;
            delete pstmt;

            cout << "Donor found!" << endl;
            cout << "Set your new password: ";

            char ch;
            while ((ch = _getch()) != 13)
            {
                DonorPassword += ch;
                cout << "*";
            }

            // Update donor password
            pstmt = conn->prepareStatement(
                "UPDATE Donor SET DonorPassword = ? WHERE DonorID = ?"
            );
            pstmt->setString(1, DonorPassword);
            pstmt->setString(2, donorID);
            pstmt->executeUpdate();

            delete pstmt;

            cout << "\nSuccessfully updated!" << endl;
            system("pause");
            MainLogin();
        }
        catch (sql::SQLException& e) {
            cout << "SQL Error: " << e.what() << endl;
            system("pause");
            MainLogin();
        }
    }

    else if (recover == 3)
    {
        MainLogin();
    }

    else
    {
        cout << "Invalid choice!" << endl;
        system("pause");
        MainLogin();
    }
}

void ShowTime()
{
    int year, month, day, hour, minute, second;
    string date, curTime;
    string morOrNight;

    // current time and date
    time_t now = time(0);
    tm ltm;  
    localtime_s(&ltm, &now);  

    year = 1900 + ltm.tm_year;
    month = 1 + ltm.tm_mon;
    day = ltm.tm_mday;

    hour = ltm.tm_hour;
    minute = ltm.tm_min;
    second = ltm.tm_sec;

    // determine am or pm
    if (hour < 12)
        morOrNight = "am";
    else if (hour == 12)
        morOrNight = "pm";
    else if (hour > 12)
    {
        morOrNight = "pm";
        hour -= 12;
    }

    // format date as DD/MM/YYYY
    date = to_string(day) + "/" + to_string(month) + "/" + to_string(year);

    // format time as HH:MM:SS am/pm with leading zeros
    char buffer[20];
    sprintf_s(buffer, "%02d:%02d:%02d %s", hour, minute, second, morOrNight.c_str());
    curTime = buffer;

    // display Date and Time
    cout << "Date: " << date << setw(15) << "  Time: " << curTime << endl;
}

int calculateAge(int year, int month, int day) {
    time_t t = time(nullptr);
    tm now = {};                 
    localtime_s(&now, &t);       

    int age = now.tm_year + 1900 - year;

    if ((now.tm_mon + 1 < month) ||
        ((now.tm_mon + 1 == month) && (now.tm_mday < day))) {
        age--;
    }

    return age;
}